/**
 * GCR Downloader - Background Service Worker
 * Handles message passing, authentication coordination, and download orchestration
 * 
 * This is the central hub that coordinates between:
 * - Content script (floating button)
 * - Popup (selection UI)
 * - APIs (Classroom, Drive)
 */

// Note: ES modules are used via manifest type: module
// Imports handled via message passing since service worker has different context

// ============================================================================
// CONSTANTS
// ============================================================================

const STORAGE_KEYS = {
    LAST_COURSE_ID: 'gcr_last_course_id',
    LAST_COURSE_NAME: 'gcr_last_course_name',
    COURSE_DATA_PREFIX: 'gcr_course_data_',
    AUTH_TOKEN: 'gcr_auth_token',
    AUTH_TIMESTAMP: 'gcr_auth_timestamp'
};

const CLASSROOM_API_BASE = 'https://classroom.googleapis.com/v1';
const DRIVE_API_BASE = 'https://www.googleapis.com/drive/v3';

// ============================================================================
// MESSAGE HANDLERS
// ============================================================================

/**
 * Main message listener
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('[GCR Background] Message received:', message.type);

    // Handle async responses
    handleMessage(message, sender)
        .then(response => {
            console.log('[GCR Background] Sending response for:', message.type);
            sendResponse(response);
        })
        .catch(error => {
            console.error('[GCR Background] Error handling message:', error);
            sendResponse({
                success: false,
                error: error.message || 'Unknown error occurred'
            });
        });

    // Return true to indicate async response
    return true;
});

/**
 * Handles incoming messages
 * @param {Object} message - Message object
 * @param {Object} sender - Sender info
 * @returns {Promise<Object>} Response
 */
async function handleMessage(message, sender) {
    switch (message.type) {
        case 'GET_AUTH_TOKEN':
            return handleGetAuthToken(message.interactive);

        case 'SIGN_OUT':
            return handleSignOut();

        case 'GET_CACHED_DATA':
            return handleGetCachedData();

        case 'FETCH_COURSE_DATA':
            return handleFetchCourseData(message.courseId, message.courseName);

        case 'GET_LAST_COURSE':
            return handleGetLastCourse();

        case 'SET_LAST_COURSE':
            return handleSetLastCourse(message.courseId, message.courseName);

        case 'GET_ITEM_COUNT':
            return handleGetItemCount();

        case 'DOWNLOAD_FILES':
            return handleDownloadFiles(message.selectedItems);

        case 'GET_DOWNLOAD_PROGRESS':
            return handleGetDownloadProgress();

        case 'CANCEL_DOWNLOADS':
            return handleCancelDownloads();

        case 'CLEAR_CACHE':
            return handleClearCache();

        default:
            console.warn('[GCR Background] Unknown message type:', message.type);
            return { success: false, error: 'Unknown message type' };
    }
}

// ============================================================================
// AUTHENTICATION HANDLERS
// ============================================================================

/**
 * Gets auth token using chrome.identity.getAuthToken
 * This is the standard method for Chrome Extensions
 * @param {boolean} interactive - Show login UI if needed
 * @returns {Promise<Object>} Token response
 */
async function handleGetAuthToken(interactive = true) {
    const manifest = chrome.runtime.getManifest();
    const clientId = manifest.oauth2?.client_id;
    const scopes = manifest.oauth2?.scopes || [];

    console.log('[GCR Background] ========== OAuth Debug Info ==========');
    console.log('[GCR Background] Extension ID:', chrome.runtime.id);
    console.log('[GCR Background] OAuth Client ID:', clientId);
    console.log('[GCR Background] Has key in manifest:', !!manifest.key);
    console.log('[GCR Background] Interactive mode:', interactive);
    console.log('[GCR Background] ======================================');

    // First, try the standard getAuthToken method
    return new Promise((resolve) => {
        chrome.identity.getAuthToken({ interactive }, async (token) => {
            if (chrome.runtime.lastError) {
                const errorMsg = chrome.runtime.lastError.message || '';
                console.warn('[GCR Background] getAuthToken failed:', errorMsg);

                // If "Authorization page could not be loaded", try launchWebAuthFlow
                if (errorMsg.includes('Authorization page could not be loaded') && interactive) {
                    console.log('[GCR Background] Trying launchWebAuthFlow fallback...');
                    try {
                        const fallbackResult = await tryLaunchWebAuthFlow(clientId, scopes);
                        resolve(fallbackResult);
                    } catch (e) {
                        console.error('[GCR Background] Fallback also failed:', e);
                        resolve({ success: false, error: errorMsg });
                    }
                    return;
                }

                resolve({ success: false, error: errorMsg });
                return;
            }

            if (!token) {
                resolve({ success: false, error: 'No token received' });
                return;
            }

            console.log('[GCR Background] Token obtained successfully!');
            chrome.storage.local.set({
                [STORAGE_KEYS.AUTH_TOKEN]: token,
                [STORAGE_KEYS.AUTH_TIMESTAMP]: Date.now()
            });
            resolve({ success: true, token });
        });
    });
}

/**
 * Fallback authentication using chrome.windows.create
 * This bypasses Chrome's identity API which has issues with consumer accounts
 * Uses Web Application OAuth client with redirect URI configured
 */
async function tryLaunchWebAuthFlow(clientId, scopes) {
    return new Promise((resolve, reject) => {
        const redirectUrl = chrome.identity.getRedirectURL();
        const scopeString = scopes.join(' ');

        // Use Web Application client ID for fallback flow
        const webClientId = '70759750296-vsjo76s29ua1evabsvgop1lrebhctpgo.apps.googleusercontent.com';

        const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?` +
            `client_id=${encodeURIComponent(webClientId)}&` +
            `response_type=token&` +
            `redirect_uri=${encodeURIComponent(redirectUrl)}&` +
            `scope=${encodeURIComponent(scopeString)}&` +
            `prompt=consent`;

        console.log('[GCR Background] Opening auth window with URL:', authUrl);
        console.log('[GCR Background] Expected redirect:', redirectUrl);

        // Create a popup window for OAuth
        chrome.windows.create({
            url: authUrl,
            type: 'popup',
            width: 500,
            height: 600
        }, (authWindow) => {
            if (chrome.runtime.lastError) {
                console.error('[GCR Background] Window create error:', chrome.runtime.lastError);
                reject(chrome.runtime.lastError);
                return;
            }

            const windowId = authWindow.id;
            console.log('[GCR Background] Auth window created:', windowId);

            // Listen for URL changes in the popup
            const handleUpdated = (tabId, changeInfo, tab) => {
                if (tab.windowId !== windowId || !changeInfo.url) return;

                console.log('[GCR Background] Tab URL changed:', changeInfo.url);

                // Check if redirected to our redirect URL
                if (changeInfo.url.startsWith(redirectUrl)) {
                    // Extract token from URL
                    try {
                        const url = new URL(changeInfo.url);
                        const hashParams = new URLSearchParams(url.hash.substring(1));
                        const token = hashParams.get('access_token');
                        const error = hashParams.get('error');

                        // Clean up listeners and close window
                        chrome.tabs.onUpdated.removeListener(handleUpdated);
                        chrome.windows.onRemoved.removeListener(handleRemoved);
                        chrome.windows.remove(windowId);

                        if (token) {
                            console.log('[GCR Background] Token obtained via popup window!');
                            chrome.storage.local.set({
                                [STORAGE_KEYS.AUTH_TOKEN]: token,
                                [STORAGE_KEYS.AUTH_TIMESTAMP]: Date.now()
                            });
                            resolve({ success: true, token });
                        } else if (error) {
                            reject(new Error(`OAuth error: ${error}`));
                        } else {
                            reject(new Error('No token in response'));
                        }
                    } catch (e) {
                        reject(e);
                    }
                }
            };

            // Listen for window close (user cancelled)
            const handleRemoved = (closedWindowId) => {
                if (closedWindowId === windowId) {
                    chrome.tabs.onUpdated.removeListener(handleUpdated);
                    chrome.windows.onRemoved.removeListener(handleRemoved);
                    reject(new Error('User closed auth window'));
                }
            };

            chrome.tabs.onUpdated.addListener(handleUpdated);
            chrome.windows.onRemoved.addListener(handleRemoved);
        });
    });
}

/**
 * Signs out the user
 * BEHAVIOR: Revokes token, clears auth state, but KEEPS cached course data
 * User can still view cache (read-only) but downloads require re-auth
 * @returns {Promise<Object>} Result
 */
async function handleSignOut() {
    return new Promise((resolve) => {
        chrome.identity.getAuthToken({ interactive: false }, async (token) => {
            if (token) {
                // Remove cached token from Chrome
                chrome.identity.removeCachedAuthToken({ token }, async () => {
                    // Revoke on Google's servers
                    try {
                        await fetch(`https://accounts.google.com/o/oauth2/revoke?token=${token}`);
                    } catch (e) {
                        console.warn('[GCR Background] Revoke failed:', e);
                    }

                    // Clear auth data only, KEEP course cache for viewing
                    // This allows offline viewing of cached data
                    chrome.storage.local.remove([
                        STORAGE_KEYS.AUTH_TOKEN,
                        STORAGE_KEYS.AUTH_TIMESTAMP
                    ]);

                    console.log('[GCR Background] Sign out complete - kept cached data');
                    resolve({ success: true, message: 'Signed out. Cached data retained for viewing.' });
                });
            } else {
                resolve({ success: true });
            }
        });
    });
}

// ============================================================================
// CACHE HANDLERS
// ============================================================================

/**
 * Gets cached course data
 * @returns {Promise<Object>} Cached data or null
 */
async function handleGetCachedData() {
    return new Promise((resolve) => {
        chrome.storage.local.get([
            STORAGE_KEYS.LAST_COURSE_ID,
            STORAGE_KEYS.LAST_COURSE_NAME
        ], (result) => {
            const courseId = result[STORAGE_KEYS.LAST_COURSE_ID];
            const courseName = result[STORAGE_KEYS.LAST_COURSE_NAME];

            if (!courseId) {
                resolve({ success: true, data: null });
                return;
            }

            // Get course data
            const dataKey = STORAGE_KEYS.COURSE_DATA_PREFIX + courseId;
            chrome.storage.local.get(dataKey, (dataResult) => {
                const courseData = dataResult[dataKey];

                if (courseData) {
                    resolve({
                        success: true,
                        data: {
                            ...courseData,
                            courseId,
                            courseName: courseName || courseData.courseName
                        }
                    });
                } else {
                    resolve({
                        success: true,
                        data: null,
                        courseId,
                        courseName
                    });
                }
            });
        });
    });
}

/**
 * Gets last visited course info
 * @returns {Promise<Object>} Course info
 */
async function handleGetLastCourse() {
    return new Promise((resolve) => {
        chrome.storage.local.get([
            STORAGE_KEYS.LAST_COURSE_ID,
            STORAGE_KEYS.LAST_COURSE_NAME
        ], (result) => {
            resolve({
                success: true,
                courseId: result[STORAGE_KEYS.LAST_COURSE_ID] || null,
                courseName: result[STORAGE_KEYS.LAST_COURSE_NAME] || null
            });
        });
    });
}

/**
 * Sets last visited course
 * @param {string} courseId - Course ID
 * @param {string} courseName - Course name
 * @returns {Promise<Object>} Result
 */
async function handleSetLastCourse(courseId, courseName) {
    return new Promise((resolve) => {
        // Get previous course ID
        chrome.storage.local.get(STORAGE_KEYS.LAST_COURSE_ID, (result) => {
            const previousCourseId = result[STORAGE_KEYS.LAST_COURSE_ID];

            // If different course, clear old data
            if (previousCourseId && previousCourseId !== courseId) {
                const oldDataKey = STORAGE_KEYS.COURSE_DATA_PREFIX + previousCourseId;
                chrome.storage.local.remove(oldDataKey);
                console.log('[GCR Background] Cleared old course data:', previousCourseId);
            }

            // Set new course
            chrome.storage.local.set({
                [STORAGE_KEYS.LAST_COURSE_ID]: courseId,
                [STORAGE_KEYS.LAST_COURSE_NAME]: courseName
            }, () => {
                resolve({ success: true });
            });
        });
    });
}

/**
 * Gets total item count from cached data
 * @returns {Promise<Object>} Count
 */
async function handleGetItemCount() {
    const cached = await handleGetCachedData();

    if (!cached.success || !cached.data) {
        return { success: true, count: 0 };
    }

    let count = 0;
    const data = cached.data;

    // Count all attachments (excluding links which go into resources file)
    const countAttachments = (items) => {
        for (const item of items || []) {
            for (const attachment of item.attachments || []) {
                if (!attachment.isLink) {
                    count++;
                }
            }
        }
    };

    countAttachments(data.assignments);
    countAttachments(data.materials);
    countAttachments(data.announcements);

    // Add 1 for resources file if there are links
    if (data.links && data.links.length > 0) {
        count++;
    }

    return { success: true, count };
}

/**
 * Clears all cache data
 * @returns {Promise<Object>} Result
 */
async function handleClearCache() {
    return new Promise((resolve) => {
        chrome.storage.local.get(null, (all) => {
            const keysToRemove = Object.keys(all).filter(key =>
                key.startsWith(STORAGE_KEYS.COURSE_DATA_PREFIX) ||
                key === STORAGE_KEYS.LAST_COURSE_ID ||
                key === STORAGE_KEYS.LAST_COURSE_NAME
            );

            if (keysToRemove.length > 0) {
                chrome.storage.local.remove(keysToRemove, () => {
                    resolve({ success: true });
                });
            } else {
                resolve({ success: true });
            }
        });
    });
}

// ============================================================================
// API HANDLERS
// ============================================================================

/**
 * Fetches course data from API
 * @param {string} courseId - Course ID
 * @param {string} courseName - Course name (optional, will be fetched if not provided)
 * @returns {Promise<Object>} Course data
 */
async function handleFetchCourseData(courseId, courseName) {
    console.log('[GCR Background] Fetching course data:', courseId);

    try {
        // Get auth token
        const authResult = await handleGetAuthToken(true);
        if (!authResult.success) {
            return { success: false, error: authResult.error };
        }
        const token = authResult.token;

        // DEBUG: First, list ALL courses to see what we have access to
        console.log('[GCR Background] DEBUG: Listing all courses...');
        try {
            const allCourses = await apiRequest(`${CLASSROOM_API_BASE}/courses?studentId=me&courseStates=ACTIVE`, token);
            console.log('[GCR Background] DEBUG: All courses response:', allCourses);
            if (allCourses.courses) {
                console.log('[GCR Background] DEBUG: Found', allCourses.courses.length, 'courses');
                allCourses.courses.forEach(c => {
                    console.log('[GCR Background] DEBUG: Course:', c.id, '-', c.name);
                });

                // Check if our target course is in the list
                const foundCourse = allCourses.courses.find(c => c.id === courseId);
                if (foundCourse) {
                    console.log('[GCR Background] DEBUG: Target course FOUND in list!', foundCourse.name);
                    courseName = foundCourse.name;
                } else {
                    console.log('[GCR Background] DEBUG: Target course NOT in list. courseId:', courseId);
                    console.log('[GCR Background] DEBUG: Available course IDs:', allCourses.courses.map(c => c.id));
                }
            } else {
                console.log('[GCR Background] DEBUG: No courses returned');
            }
        } catch (listError) {
            console.error('[GCR Background] DEBUG: Failed to list courses:', listError);
        }

        // Fetch course info if name not provided
        if (!courseName) {
            const courseInfo = await apiRequest(`${CLASSROOM_API_BASE}/courses/${courseId}`, token);
            courseName = courseInfo.name || 'Unknown Course';
        }

        // Fetch all data in parallel
        const [coursework, materials, announcements] = await Promise.all([
            fetchCoursework(courseId, token).catch(e => {
                console.warn('[GCR Background] Coursework error:', e);
                return [];
            }),
            fetchMaterials(courseId, token).catch(e => {
                console.warn('[GCR Background] Materials error:', e);
                return [];
            }),
            fetchAnnouncements(courseId, token).catch(e => {
                console.warn('[GCR Background] Announcements error:', e);
                return [];
            })
        ]);

        // Collect links
        const links = [];
        const collectLinks = (items) => {
            for (const item of items) {
                for (const attachment of item.attachments || []) {
                    if (attachment.isLink) {
                        links.push({
                            ...attachment,
                            parentTitle: item.title,
                            parentType: item.type
                        });
                    }
                }
            }
        };
        collectLinks(coursework);
        collectLinks(materials);
        collectLinks(announcements);

        // Count total items
        let totalItems = links.length > 0 ? 1 : 0; // +1 for resources file
        const countItems = (items) => {
            for (const item of items) {
                totalItems += (item.attachments || []).filter(a => !a.isLink).length;
            }
        };
        countItems(coursework);
        countItems(materials);
        countItems(announcements);

        const courseData = {
            courseId,
            courseName,
            timestamp: Date.now(),
            assignments: coursework,
            materials,
            announcements,
            links,
            totalItems
        };

        // Cache the data
        const dataKey = STORAGE_KEYS.COURSE_DATA_PREFIX + courseId;
        await new Promise(resolve => {
            chrome.storage.local.set({
                [dataKey]: courseData,
                [STORAGE_KEYS.LAST_COURSE_ID]: courseId,
                [STORAGE_KEYS.LAST_COURSE_NAME]: courseName
            }, resolve);
        });

        console.log('[GCR Background] Course data cached:', totalItems, 'items');

        return { success: true, data: courseData };

    } catch (error) {
        console.error('[GCR Background] Fetch error:', error);
        return { success: false, error: error.message };
    }
}

/**
 * Makes an API request
 * @param {string} url - URL to request
 * @param {string} token - Auth token
 * @returns {Promise<Object>} Response data
 */
async function apiRequest(url, token) {
    console.log('[GCR Background] API Request:', url);

    const response = await fetch(url, {
        headers: { 'Authorization': `Bearer ${token}` }
    });

    if (!response.ok) {
        // Try to get more error details
        let errorBody = '';
        try {
            const errorJson = await response.json();
            errorBody = JSON.stringify(errorJson);
            console.error('[GCR Background] API Error Body:', errorJson);
        } catch (e) {
            errorBody = await response.text().catch(() => '');
        }

        console.error('[GCR Background] API Error:', response.status, 'URL:', url, 'Body:', errorBody);

        const error = new Error(`API error: ${response.status}`);
        error.status = response.status;
        error.body = errorBody;
        throw error;
    }

    return response.json();
}

/**
 * Fetches coursework for a course
 * @param {string} courseId - Course ID
 * @param {string} token - Auth token
 * @returns {Promise<Array>} Coursework items
 */
async function fetchCoursework(courseId, token) {
    const items = [];
    let pageToken = null;

    do {
        const url = new URL(`${CLASSROOM_API_BASE}/courses/${courseId}/courseWork`);
        url.searchParams.set('pageSize', '50');
        if (pageToken) url.searchParams.set('pageToken', pageToken);

        try {
            const data = await apiRequest(url.toString(), token);

            if (data.courseWork) {
                for (const work of data.courseWork) {
                    items.push({
                        id: work.id,
                        title: work.title || 'Untitled Assignment',
                        type: 'courseWork',
                        attachments: processMaterials(work.materials)
                    });
                }
            }

            pageToken = data.nextPageToken;
        } catch (e) {
            if (e.status === 404) break;
            throw e;
        }
    } while (pageToken);

    return items;
}

/**
 * Fetches course materials
 * @param {string} courseId - Course ID
 * @param {string} token - Auth token
 * @returns {Promise<Array>} Material items
 */
async function fetchMaterials(courseId, token) {
    const items = [];
    let pageToken = null;

    do {
        const url = new URL(`${CLASSROOM_API_BASE}/courses/${courseId}/courseWorkMaterials`);
        url.searchParams.set('pageSize', '50');
        if (pageToken) url.searchParams.set('pageToken', pageToken);

        try {
            const data = await apiRequest(url.toString(), token);

            if (data.courseWorkMaterial) {
                for (const material of data.courseWorkMaterial) {
                    items.push({
                        id: material.id,
                        title: material.title || 'Untitled Material',
                        type: 'courseWorkMaterial',
                        attachments: processMaterials(material.materials)
                    });
                }
            }

            pageToken = data.nextPageToken;
        } catch (e) {
            if (e.status === 404) break;
            throw e;
        }
    } while (pageToken);

    return items;
}

/**
 * Fetches announcements
 * @param {string} courseId - Course ID
 * @param {string} token - Auth token
 * @returns {Promise<Array>} Announcement items
 */
async function fetchAnnouncements(courseId, token) {
    const items = [];
    let pageToken = null;

    do {
        const url = new URL(`${CLASSROOM_API_BASE}/courses/${courseId}/announcements`);
        url.searchParams.set('pageSize', '50');
        if (pageToken) url.searchParams.set('pageToken', pageToken);

        try {
            const data = await apiRequest(url.toString(), token);

            if (data.announcements) {
                for (const announcement of data.announcements) {
                    items.push({
                        id: announcement.id,
                        title: announcement.text?.substring(0, 50) || 'Announcement',
                        type: 'announcement',
                        attachments: processMaterials(announcement.materials)
                    });
                }
            }

            pageToken = data.nextPageToken;
        } catch (e) {
            if (e.status === 404) break;
            throw e;
        }
    } while (pageToken);

    return items;
}

/**
 * Processes material attachments
 * @param {Array} materials - Materials array from API
 * @returns {Array} Processed attachments
 */
function processMaterials(materials) {
    if (!materials) return [];

    const attachments = [];

    for (const material of materials) {
        if (material.driveFile) {
            const file = material.driveFile.driveFile || material.driveFile;
            attachments.push({
                type: 'driveFile',
                id: file.id,
                title: file.title || 'Untitled File',
                mimeType: file.mimeType,
                alternateLink: file.alternateLink,
                isGoogleFile: file.mimeType?.startsWith('application/vnd.google-apps.'),
                isLink: false
            });
        } else if (material.youtubeVideo) {
            attachments.push({
                type: 'youtube',
                id: material.youtubeVideo.id,
                title: material.youtubeVideo.title || 'YouTube Video',
                alternateLink: material.youtubeVideo.alternateLink,
                isLink: true
            });
        } else if (material.link) {
            attachments.push({
                type: 'link',
                url: material.link.url,
                title: material.link.title || material.link.url,
                isLink: true
            });
        } else if (material.form) {
            attachments.push({
                type: 'form',
                title: material.form.title || 'Google Form',
                formUrl: material.form.formUrl,
                isLink: true
            });
        }
    }

    return attachments;
}

// ============================================================================
// DOWNLOAD HANDLERS
// ============================================================================

// Download state
let downloadState = {
    active: false,
    total: 0,
    completed: 0,
    failed: 0,
    results: { success: [], failed: [] }
};

/**
 * Handles file downloads
 * @param {Array} selectedItems - Selected item IDs (or null for all)
 * @returns {Promise<Object>} Download results
 */
async function handleDownloadFiles(selectedItems) {
    console.log('[GCR Background] Starting downloads');

    // Get cached data
    const cached = await handleGetCachedData();
    if (!cached.success || !cached.data) {
        return { success: false, error: 'No course data cached' };
    }

    const courseData = cached.data;

    // Reset state
    downloadState = {
        active: true,
        total: 0,
        completed: 0,
        failed: 0,
        results: { success: [], failed: [] }
    };

    // Get auth token
    const authResult = await handleGetAuthToken(true);
    if (!authResult.success) {
        return { success: false, error: 'Authentication required' };
    }
    const token = authResult.token;

    // Collect files to download WITH DEDUPLICATION
    // Files are uniquely identified by Drive file ID
    // Same file appearing in multiple categories is downloaded only once
    const filesToDownload = [];
    const links = [];
    const seenFileIds = new Set(); // Track seen file IDs for deduplication

    const collectFiles = (items) => {
        for (const item of items || []) {
            for (const attachment of item.attachments || []) {
                if (selectedItems && !selectedItems.includes(attachment.id)) continue;

                if (attachment.isLink) {
                    links.push({ ...attachment, parentTitle: item.title });
                } else {
                    // DEDUPLICATION: Skip if we've already seen this file ID
                    if (attachment.id && seenFileIds.has(attachment.id)) {
                        console.log('[GCR Background] Skipping duplicate file:', attachment.title);
                        continue;
                    }
                    seenFileIds.add(attachment.id);
                    filesToDownload.push({ ...attachment, parentTitle: item.title });
                }
            }
        }
    };

    collectFiles(courseData.assignments);
    collectFiles(courseData.materials);
    collectFiles(courseData.announcements);

    // Check for offline before starting
    if (!isOnline()) {
        downloadState.active = false;
        return {
            success: false,
            error: 'No internet connection. Downloads require network access.',
            offline: true
        };
    }

    downloadState.total = filesToDownload.length + (links.length > 0 ? 1 : 0);

    // Download files
    const courseFolderName = sanitizeFolderName(courseData.courseName || 'Downloads');
    const usedNames = new Set();

    console.log('[GCR Background] Files to download:', filesToDownload.length);
    console.log('[GCR Background] Links found:', links.length);
    console.log('[GCR Background] Course folder:', courseFolderName);

    for (const file of filesToDownload) {
        if (!downloadState.active) break;

        console.log('[GCR Background] Downloading file:', file.title, 'ID:', file.id, 'MIME:', file.mimeType);

        try {
            await downloadFile(file, token, courseFolderName, usedNames);
            downloadState.completed++;
            downloadState.results.success.push(file.title);
            console.log('[GCR Background] Download SUCCESS:', file.title);
        } catch (error) {
            downloadState.failed++;
            downloadState.results.failed.push({ title: file.title, error: error.message });
            console.error('[GCR Background] Download FAILED:', file.title, 'Error:', error.message);
        }
    }

    // Create resources file
    if (links.length > 0 && downloadState.active) {
        try {
            await createResourcesFile(links, courseData.courseName, courseFolderName);
            downloadState.completed++;
            downloadState.results.success.push('_Links_and_Resources.txt');
        } catch (error) {
            downloadState.failed++;
            downloadState.results.failed.push({ title: 'Resources', error: error.message });
        }
    }

    downloadState.active = false;

    return {
        success: true,
        total: downloadState.total,
        completed: downloadState.completed,
        failed: downloadState.failed,
        results: downloadState.results
    };
}

/**
 * Downloads a single file
 * @param {Object} file - File object
 * @param {string} token - Auth token
 * @param {string} folderName - Folder name
 * @param {Set} usedNames - Set of used filenames
 */
async function downloadFile(file, token, folderName, usedNames) {
    const { id, title, mimeType } = file;

    let url;
    let extension = '';

    // Check if Google Workspace file needing export
    if (mimeType?.startsWith('application/vnd.google-apps.')) {
        const exportFormats = {
            'application/vnd.google-apps.document': { mime: 'application/pdf', ext: '.pdf' },
            'application/vnd.google-apps.spreadsheet': { mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', ext: '.xlsx' },
            'application/vnd.google-apps.presentation': { mime: 'application/pdf', ext: '.pdf' },
            'application/vnd.google-apps.drawing': { mime: 'image/png', ext: '.png' }
        };

        const format = exportFormats[mimeType];
        if (!format) {
            throw new Error('Cannot export this file type');
        }

        url = `${DRIVE_API_BASE}/files/${id}/export?mimeType=${encodeURIComponent(format.mime)}`;
        extension = format.ext;
    } else {
        // For regular files, use alt=media to get direct download
        url = `${DRIVE_API_BASE}/files/${id}?alt=media`;
    }

    // Build filename
    let filename = sanitizeFilename(title);
    if (extension && !filename.toLowerCase().endsWith(extension)) {
        const lastDot = filename.lastIndexOf('.');
        if (lastDot > 0) filename = filename.substring(0, lastDot);
        filename += extension;
    }

    // Make unique
    let counter = 0;
    let uniqueName = filename;
    while (usedNames.has(uniqueName)) {
        counter++;
        const dot = filename.lastIndexOf('.');
        if (dot > 0) {
            uniqueName = `${filename.substring(0, dot)}(${counter})${filename.substring(dot)}`;
        } else {
            uniqueName = `${filename}(${counter})`;
        }
    }
    usedNames.add(uniqueName);

    console.log('[GCR Background] Download URL:', url);
    console.log('[GCR Background] Saving as:', `${folderName}/${uniqueName}`);

    // Use chrome.downloads.download with authorization header
    // Since service workers can't use URL.createObjectURL, we fetch and convert to data URL
    const response = await fetch(url, {
        headers: { 'Authorization': `Bearer ${token}` }
    });

    if (!response.ok) {
        throw new Error(`Download failed: ${response.status}`);
    }

    // Convert response to base64 data URL (works in service workers)
    const blob = await response.blob();
    const reader = new FileReader();

    const dataUrl = await new Promise((resolve, reject) => {
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });

    // Download using data URL
    return new Promise((resolve, reject) => {
        chrome.downloads.download({
            url: dataUrl,
            filename: `${folderName}/${uniqueName}`,
            saveAs: false
        }, (downloadId) => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else if (downloadId === undefined) {
                reject(new Error('Download failed to start'));
            } else {
                console.log('[GCR Background] Download started, ID:', downloadId);
                resolve(downloadId);
            }
        });
    });
}

/**
 * Creates resources file
 * @param {Array} links - Links array
 * @param {string} courseName - Course name
 * @param {string} folderName - Folder name
 */
async function createResourcesFile(links, courseName, folderName) {
    let content = `# Resources and Links\n`;
    content += `# Course: ${courseName}\n`;
    content += `# Generated: ${new Date().toLocaleString()}\n\n`;

    for (const link of links) {
        content += `[${link.type}] ${link.title}\n`;
        content += `  URL: ${link.alternateLink || link.url || link.formUrl}\n`;
        if (link.parentTitle) content += `  From: ${link.parentTitle}\n`;
        content += `\n`;
    }

    const blob = new Blob([content], { type: 'text/plain' });
    const objectUrl = URL.createObjectURL(blob);

    return new Promise((resolve, reject) => {
        chrome.downloads.download({
            url: objectUrl,
            filename: `${folderName}/_Links_and_Resources.txt`,
            saveAs: false
        }, (downloadId) => {
            setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);

            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else {
                resolve(downloadId);
            }
        });
    });
}

/**
 * Gets download progress
 * @returns {Object} Progress info
 */
function handleGetDownloadProgress() {
    return {
        success: true,
        active: downloadState.active,
        total: downloadState.total,
        completed: downloadState.completed,
        failed: downloadState.failed,
        percent: downloadState.total > 0
            ? Math.round((downloadState.completed / downloadState.total) * 100)
            : 0
    };
}

/**
 * Cancels downloads
 * @returns {Object} Result
 */
function handleCancelDownloads() {
    downloadState.active = false;
    return { success: true };
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Sanitizes a filename
 * @param {string} name - Original filename
 * @returns {string} Sanitized filename
 */
function sanitizeFilename(name) {
    if (!name) return 'download';

    return name
        .replace(/[<>:"/\\|?*\x00-\x1f]/g, '_')
        .replace(/[\u{1F300}-\u{1FAFF}]/gu, '')
        .replace(/\s+/g, '_')
        .replace(/_+/g, '_')
        .trim()
        .substring(0, 100) || 'download';
}

/**
 * Sanitizes a folder name
 * @param {string} name - Original name
 * @returns {string} Sanitized name
 */
function sanitizeFolderName(name) {
    return sanitizeFilename(name).replace(/\./g, '_');
}

// ============================================================================
// MULTI-TAB SYNCHRONIZATION
// ============================================================================

/**
 * Listen for storage changes to sync across tabs
 * When course data changes in one tab, other tabs get notified
 */
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace !== 'local') return;

    // If last course changed, notify all tabs
    if (changes[STORAGE_KEYS.LAST_COURSE_ID] || changes[STORAGE_KEYS.LAST_COURSE_NAME]) {
        const newCourseId = changes[STORAGE_KEYS.LAST_COURSE_ID]?.newValue;
        const newCourseName = changes[STORAGE_KEYS.LAST_COURSE_NAME]?.newValue;

        console.log('[GCR Background] Course changed in storage, syncing tabs:', newCourseId);

        // Notify all classroom tabs
        chrome.tabs.query({ url: '*://classroom.google.com/*' }, (tabs) => {
            for (const tab of tabs) {
                chrome.tabs.sendMessage(tab.id, {
                    type: 'COURSE_DATA_UPDATED',
                    courseId: newCourseId,
                    courseName: newCourseName
                }).catch(() => { });
            }
        });
    }
});

// ============================================================================
// OFFLINE DETECTION
// ============================================================================

/**
 * Checks if the browser is online
 * @returns {boolean} True if online
 */
function isOnline() {
    return navigator.onLine !== false;
}

// ============================================================================
// INITIALIZATION
// ============================================================================

console.log('[GCR Background] Service worker started');

// Handle installation
chrome.runtime.onInstalled.addListener((details) => {
    console.log('[GCR Background] Extension installed:', details.reason);

    if (details.reason === 'install') {
        // First install - could show welcome page
        console.log('[GCR Background] First install complete');
    }
});

// Keep service worker alive for downloads
chrome.downloads.onChanged.addListener((delta) => {
    if (delta.state?.current === 'complete' || delta.state?.current === 'interrupted') {
        console.log('[GCR Background] Download state changed:', delta);
    }
});
