/**
 * GCR Downloader - Popup Script
 * Handles the extension popup UI and interactions
 */

// ============================================================================
// STATE
// ============================================================================

let currentState = 'loading';
let courseData = null;

// ============================================================================
// DOM ELEMENTS
// ============================================================================

const elements = {
    // States
    stateEmpty: document.getElementById('state-empty'),
    stateLoading: document.getElementById('state-loading'),
    stateError: document.getElementById('state-error'),
    stateAuth: document.getElementById('state-auth'),
    stateData: document.getElementById('state-data'),

    // Header buttons
    refreshBtn: document.getElementById('refresh-btn'),
    clearBtn: document.getElementById('clear-btn'),

    // Error state
    errorMessage: document.getElementById('error-message'),
    retryBtn: document.getElementById('retry-btn'),

    // Auth state
    signInBtn: document.getElementById('sign-in-btn'),

    // Data state
    userInfo: document.getElementById('user-info'),
    userEmail: document.getElementById('user-email'),
    signOutBtn: document.getElementById('sign-out-btn'),
    courseName: document.getElementById('course-name'),
    itemCount: document.getElementById('item-count'),
    lastUpdated: document.getElementById('last-updated'),
    statAssignments: document.getElementById('stat-assignments'),
    statMaterials: document.getElementById('stat-materials'),
    statAnnouncements: document.getElementById('stat-announcements'),
    downloadAllBtn: document.getElementById('download-all-btn'),
    openClassroomBtn: document.getElementById('open-classroom-btn'),

    // Progress
    progressSection: document.getElementById('progress-section'),
    progressText: document.getElementById('progress-text'),
    progressFill: document.getElementById('progress-fill'),
    cancelBtn: document.getElementById('cancel-btn')
};

// ============================================================================
// STATE MANAGEMENT
// ============================================================================

/**
 * Shows a specific state and hides others
 * @param {string} stateName - State to show
 */
function showState(stateName) {
    currentState = stateName;

    // Hide all states
    document.querySelectorAll('.state').forEach(el => {
        el.classList.remove('active');
    });

    // Show requested state
    const stateEl = document.getElementById(`state-${stateName}`);
    if (stateEl) {
        stateEl.classList.add('active');
    }
}

/**
 * Shows error state with message
 * @param {string} message - Error message
 */
function showError(message) {
    elements.errorMessage.textContent = message;
    showState('error');
}

// ============================================================================
// DATA LOADING
// ============================================================================

/**
 * Loads cached data from background
 */
async function loadCachedData() {
    showState('loading');

    try {
        const response = await sendMessage({ type: 'GET_CACHED_DATA' });

        if (!response.success) {
            showError(response.error || 'Failed to load data');
            return;
        }

        if (!response.data) {
            showState('empty');
            return;
        }

        courseData = response.data;
        displayCourseData(courseData);
        showState('data');

    } catch (error) {
        console.error('[GCR Popup] Load error:', error);
        showError(error.message);
    }
}

/**
 * Displays course data in the UI
 * @param {Object} data - Course data
 */
function displayCourseData(data) {
    // Course info
    elements.courseName.textContent = data.courseName || 'Unknown Course';
    elements.itemCount.textContent = `${data.totalItems || 0} items`;

    // Last updated
    if (data.timestamp) {
        elements.lastUpdated.textContent = formatRelativeTime(data.timestamp);
    } else {
        elements.lastUpdated.textContent = 'Just now';
    }

    // Stats
    const assignmentCount = countAttachments(data.assignments);
    const materialCount = countAttachments(data.materials);
    const announcementCount = countAttachments(data.announcements);

    elements.statAssignments.textContent = assignmentCount;
    elements.statMaterials.textContent = materialCount;
    elements.statAnnouncements.textContent = announcementCount;
}

/**
 * Counts total attachments in items
 * @param {Array} items - Array of items
 * @returns {number} Total count
 */
function countAttachments(items) {
    if (!items) return 0;
    return items.reduce((sum, item) => sum + (item.attachments?.length || 0), 0);
}

/**
 * Formats a timestamp as relative time
 * @param {number} timestamp - Unix timestamp
 * @returns {string} Relative time string
 */
function formatRelativeTime(timestamp) {
    const now = Date.now();
    const diff = now - timestamp;

    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
}

// ============================================================================
// ACTIONS
// ============================================================================

/**
 * Refreshes course data
 */
async function refreshData() {
    showState('loading');

    try {
        // Get last course info
        const lastCourse = await sendMessage({ type: 'GET_LAST_COURSE' });

        if (!lastCourse.success || !lastCourse.courseId) {
            showState('empty');
            return;
        }

        // Fetch fresh data
        const response = await sendMessage({
            type: 'FETCH_COURSE_DATA',
            courseId: lastCourse.courseId,
            courseName: lastCourse.courseName
        });

        if (response.success && response.data) {
            courseData = response.data;
            displayCourseData(courseData);
            showState('data');
        } else {
            showError(response.error || 'Failed to refresh data');
        }
    } catch (error) {
        console.error('[GCR Popup] Refresh error:', error);
        showError(error.message);
    }
}

/**
 * Clears cached data
 */
async function clearCache() {
    if (!confirm('Clear all cached course data?')) return;

    try {
        await sendMessage({ type: 'CLEAR_CACHE' });
        courseData = null;
        showState('empty');
    } catch (error) {
        console.error('[GCR Popup] Clear error:', error);
    }
}

/**
 * Signs in the user
 */
async function signIn() {
    try {
        const response = await sendMessage({ type: 'GET_AUTH_TOKEN', interactive: true });

        if (response.success) {
            // Reload data after sign in
            loadCachedData();
        } else {
            showError(response.error || 'Sign in failed');
        }
    } catch (error) {
        console.error('[GCR Popup] Sign in error:', error);
        showError(error.message);
    }
}

/**
 * Signs out the user
 */
async function signOut() {
    if (!confirm('Sign out of GCR Downloader?')) return;

    try {
        await sendMessage({ type: 'SIGN_OUT' });
        await sendMessage({ type: 'CLEAR_CACHE' });
        showState('auth');
    } catch (error) {
        console.error('[GCR Popup] Sign out error:', error);
    }
}

/**
 * Downloads all files
 */
async function downloadAll() {
    if (!courseData) {
        showError('No course data available');
        return;
    }

    // Show progress
    elements.progressSection.classList.remove('hidden');
    elements.downloadAllBtn.disabled = true;

    try {
        // Start download
        const response = await sendMessage({
            type: 'DOWNLOAD_FILES',
            selectedItems: null // null = all items
        });

        if (!response.success) {
            showError(response.error || 'Download failed');
            return;
        }

        // Monitor progress
        await monitorProgress();

        // Show completion
        const successCount = response.completed || 0;
        const failedCount = response.failed || 0;

        if (failedCount === 0) {
            alert(`✅ Download complete!\n${successCount} files downloaded.`);
        } else {
            alert(`⚠️ Download complete with errors.\n${successCount} succeeded, ${failedCount} failed.`);
        }

    } catch (error) {
        console.error('[GCR Popup] Download error:', error);
        showError(error.message);
    } finally {
        elements.progressSection.classList.add('hidden');
        elements.downloadAllBtn.disabled = false;
    }
}

/**
 * Monitors download progress
 */
async function monitorProgress() {
    while (true) {
        const response = await sendMessage({ type: 'GET_DOWNLOAD_PROGRESS' });

        if (!response.success || !response.active) {
            break;
        }

        elements.progressText.textContent = `Downloading... ${response.completed}/${response.total}`;
        elements.progressFill.style.width = `${response.percent}%`;

        await new Promise(r => setTimeout(r, 500));
    }
}

/**
 * Cancels ongoing download
 */
async function cancelDownload() {
    await sendMessage({ type: 'CANCEL_DOWNLOADS' });
    elements.progressSection.classList.add('hidden');
    elements.downloadAllBtn.disabled = false;
}

/**
 * Opens Google Classroom in a new tab
 */
function openClassroom() {
    if (courseData?.courseId) {
        chrome.tabs.create({
            url: `https://classroom.google.com/c/${courseData.courseId}`
        });
    } else {
        chrome.tabs.create({
            url: 'https://classroom.google.com'
        });
    }
}

// ============================================================================
// MESSAGE PASSING
// ============================================================================

/**
 * Sends a message to the background script
 * @param {Object} message - Message to send
 * @returns {Promise<Object>} Response
 */
function sendMessage(message) {
    return new Promise((resolve, reject) => {
        try {
            chrome.runtime.sendMessage(message, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response || { success: false, error: 'No response' });
                }
            });
        } catch (error) {
            reject(error);
        }
    });
}

// ============================================================================
// EVENT LISTENERS
// ============================================================================

// Header buttons
elements.refreshBtn?.addEventListener('click', refreshData);
elements.clearBtn?.addEventListener('click', clearCache);

// Error state
elements.retryBtn?.addEventListener('click', loadCachedData);

// Auth state
elements.signInBtn?.addEventListener('click', signIn);

// Data state
elements.signOutBtn?.addEventListener('click', signOut);
elements.downloadAllBtn?.addEventListener('click', downloadAll);
elements.openClassroomBtn?.addEventListener('click', openClassroom);

// Progress
elements.cancelBtn?.addEventListener('click', cancelDownload);

// ============================================================================
// INITIALIZATION
// ============================================================================

// Load data when popup opens
document.addEventListener('DOMContentLoaded', () => {
    console.log('[GCR Popup] Initializing...');
    loadCachedData();
});

console.log('[GCR Popup] Script loaded');
