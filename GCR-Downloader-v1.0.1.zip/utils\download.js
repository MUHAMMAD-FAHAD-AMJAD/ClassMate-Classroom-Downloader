/**
 * GCR Downloader - Download Manager Module
 * Handles file downloads with concurrent limiting and progress tracking
 * 
 * Features:
 * - Concurrent download limiting (max 5 simultaneous)
 * - File type detection and Google Workspace exports
 * - Filename sanitization (emojis, special chars)
 * - Resources file generation for links/YouTube/Forms
 * - Progress tracking and cancellation
 * - Retry on failure
 */

import { getAuthToken } from './auth.js';
import {
    sanitizeFilename,
    makeUniqueFilename,
    ensureExtension,
    GOOGLE_EXPORT_FORMATS,
    isGoogleWorkspaceFile,
    getFileIcon,
    delay
} from './helpers.js';

// ============================================================================
// CONSTANTS
// ============================================================================

/**
 * Maximum concurrent downloads
 */
const MAX_CONCURRENT_DOWNLOADS = 5;

/**
 * Maximum retry attempts for failed downloads
 */
const MAX_DOWNLOAD_RETRIES = 3;

/**
 * Delay between retries (ms)
 */
const RETRY_DELAY_MS = 2000;

/**
 * Drive API base URL
 */
const DRIVE_API_BASE = 'https://www.googleapis.com/drive/v3';

// ============================================================================
// STATE
// ============================================================================

/**
 * Current download queue
 */
let downloadQueue = [];

/**
 * Active downloads count
 */
let activeDownloads = 0;

/**
 * Download progress tracking
 */
let downloadProgress = {
    total: 0,
    completed: 0,
    failed: 0,
    inProgress: 0
};

/**
 * Progress callback
 */
let progressCallback = null;

/**
 * Set of used filenames (for uniqueness)
 */
let usedFilenames = new Set();

/**
 * Download abort flag
 */
let abortDownloads = false;

// ============================================================================
// PROGRESS TRACKING
// ============================================================================

/**
 * Resets download progress
 */
function resetProgress() {
    downloadProgress = {
        total: 0,
        completed: 0,
        failed: 0,
        inProgress: 0
    };
    usedFilenames.clear();
    abortDownloads = false;
}

/**
 * Updates and notifies progress
 */
function updateProgress() {
    if (progressCallback) {
        progressCallback({
            ...downloadProgress,
            percent: downloadProgress.total > 0
                ? Math.round((downloadProgress.completed / downloadProgress.total) * 100)
                : 0
        });
    }
}

/**
 * Sets the progress callback
 * @param {Function} callback - Callback function
 */
export function setProgressCallback(callback) {
    progressCallback = callback;
}

/**
 * Gets current download progress
 * @returns {Object} Progress object
 */
export function getProgress() {
    return { ...downloadProgress };
}

// ============================================================================
// DOWNLOAD FUNCTIONS
// ============================================================================

/**
 * Downloads a single Drive file
 * @param {Object} attachment - Attachment object
 * @param {string} courseFolderName - Folder name for organization
 * @returns {Promise<Object>} Download result
 */
async function downloadDriveFile(attachment, courseFolderName) {
    const { id, title, mimeType } = attachment;

    console.log('[GCR Download] Downloading:', title, mimeType);

    // Get auth token
    const token = await getAuthToken(true);

    let downloadUrl;
    let finalExtension = '';

    // Determine download URL based on file type
    if (isGoogleWorkspaceFile(mimeType)) {
        const exportFormat = GOOGLE_EXPORT_FORMATS[mimeType];

        if (!exportFormat) {
            // Cannot export (e.g., Forms) - skip
            console.log('[GCR Download] Cannot export:', mimeType);
            return {
                success: false,
                error: 'Cannot download this file type',
                skipped: true
            };
        }

        downloadUrl = `${DRIVE_API_BASE}/files/${id}/export?mimeType=${encodeURIComponent(exportFormat.mimeType)}`;
        finalExtension = exportFormat.extension;
    } else {
        downloadUrl = `${DRIVE_API_BASE}/files/${id}?alt=media`;
    }

    // Build filename
    let filename = sanitizeFilename(title, 'download');
    filename = ensureExtension(filename, mimeType);

    // Add export extension if needed
    if (finalExtension && !filename.toLowerCase().endsWith(finalExtension)) {
        // Remove any existing extension that doesn't match
        const lastDot = filename.lastIndexOf('.');
        if (lastDot > 0) {
            filename = filename.substring(0, lastDot);
        }
        filename += finalExtension;
    }

    // Make unique
    filename = makeUniqueFilename(filename, usedFilenames);

    // Add course folder prefix if provided
    if (courseFolderName) {
        filename = `${sanitizeFilename(courseFolderName)}/${filename}`;
    }

    try {
        // Fetch the file
        const response = await fetch(downloadUrl, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error(`Download failed: ${response.status}`);
        }

        // Get blob
        const blob = await response.blob();

        // Create object URL
        const objectUrl = URL.createObjectURL(blob);

        // Trigger download via chrome.downloads API
        return new Promise((resolve, reject) => {
            chrome.downloads.download({
                url: objectUrl,
                filename: filename,
                saveAs: false
            }, (downloadId) => {
                // Clean up object URL after a delay
                setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);

                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve({
                        success: true,
                        downloadId,
                        filename
                    });
                }
            });
        });

    } catch (error) {
        console.error('[GCR Download] Error downloading:', title, error);
        throw error;
    }
}

/**
 * Downloads a file with retry logic
 * @param {Object} attachment - Attachment object
 * @param {string} courseFolderName - Folder name
 * @returns {Promise<Object>} Download result
 */
async function downloadWithRetry(attachment, courseFolderName) {
    let lastError;

    for (let attempt = 0; attempt < MAX_DOWNLOAD_RETRIES; attempt++) {
        if (abortDownloads) {
            return { success: false, error: 'Download cancelled', cancelled: true };
        }

        try {
            return await downloadDriveFile(attachment, courseFolderName);
        } catch (error) {
            lastError = error;

            // Don't retry on permission errors
            if (error.message?.includes('403') || error.message?.includes('404')) {
                return {
                    success: false,
                    error: error.message,
                    skipped: true
                };
            }

            if (attempt < MAX_DOWNLOAD_RETRIES - 1) {
                console.log(`[GCR Download] Retry ${attempt + 1}/${MAX_DOWNLOAD_RETRIES} for:`, attachment.title);
                await delay(RETRY_DELAY_MS);
            }
        }
    }

    return {
        success: false,
        error: lastError?.message || 'Download failed after retries'
    };
}

// ============================================================================
// QUEUE PROCESSING
// ============================================================================

/**
 * Processes the download queue
 */
async function processQueue() {
    while (downloadQueue.length > 0 && !abortDownloads) {
        // Wait if we're at max concurrent
        if (activeDownloads >= MAX_CONCURRENT_DOWNLOADS) {
            await delay(100);
            continue;
        }

        // Get next item
        const item = downloadQueue.shift();
        if (!item) continue;

        activeDownloads++;
        downloadProgress.inProgress++;
        updateProgress();

        // Process download
        try {
            const result = await downloadWithRetry(item.attachment, item.courseFolderName);

            if (result.success) {
                downloadProgress.completed++;
                item.resolve(result);
            } else if (result.skipped) {
                downloadProgress.completed++; // Count as completed but note it was skipped
                item.resolve(result);
            } else {
                downloadProgress.failed++;
                item.reject(new Error(result.error));
            }
        } catch (error) {
            downloadProgress.failed++;
            item.reject(error);
        } finally {
            activeDownloads--;
            downloadProgress.inProgress--;
            updateProgress();
        }
    }
}

/**
 * Adds a file to the download queue
 * @param {Object} attachment - Attachment to download
 * @param {string} courseFolderName - Course folder name
 * @returns {Promise<Object>} Download result
 */
function queueDownload(attachment, courseFolderName) {
    return new Promise((resolve, reject) => {
        downloadQueue.push({
            attachment,
            courseFolderName,
            resolve,
            reject
        });

        // Start processing if not already running
        processQueue();
    });
}

// ============================================================================
// RESOURCES FILE GENERATION
// ============================================================================

/**
 * Creates a resources file containing links, YouTube videos, and forms
 * @param {Array} links - Array of link objects
 * @param {string} courseName - Course name
 * @returns {Promise<Object>} Download result
 */
async function createResourcesFile(links, courseName) {
    if (!links || links.length === 0) {
        return { success: true, skipped: true };
    }

    console.log('[GCR Download] Creating resources file with', links.length, 'items');

    // Group by type
    const youtube = links.filter(l => l.type === 'youtube');
    const forms = links.filter(l => l.type === 'form');
    const otherLinks = links.filter(l => l.type === 'link');

    // Build file content
    let content = `# Resources and Links\n`;
    content += `# Course: ${courseName}\n`;
    content += `# Generated: ${new Date().toLocaleString()}\n`;
    content += `# Total: ${links.length} items\n`;
    content += `\n${'='.repeat(60)}\n\n`;

    if (youtube.length > 0) {
        content += `## YouTube Videos (${youtube.length})\n\n`;
        for (const item of youtube) {
            content += `${getFileIcon(null, 'youtube')} ${item.title}\n`;
            content += `   URL: ${item.alternateLink}\n`;
            if (item.parentTitle) {
                content += `   From: ${item.parentTitle}\n`;
            }
            content += `\n`;
        }
        content += `\n`;
    }

    if (forms.length > 0) {
        content += `## Google Forms (${forms.length})\n\n`;
        for (const item of forms) {
            content += `${getFileIcon(null, 'form')} ${item.title}\n`;
            content += `   Form URL: ${item.formUrl}\n`;
            if (item.responseUrl) {
                content += `   Response URL: ${item.responseUrl}\n`;
            }
            if (item.parentTitle) {
                content += `   From: ${item.parentTitle}\n`;
            }
            content += `\n`;
        }
        content += `\n`;
    }

    if (otherLinks.length > 0) {
        content += `## External Links (${otherLinks.length})\n\n`;
        for (const item of otherLinks) {
            content += `${getFileIcon(null, 'link')} ${item.title}\n`;
            content += `   URL: ${item.url}\n`;
            if (item.parentTitle) {
                content += `   From: ${item.parentTitle}\n`;
            }
            content += `\n`;
        }
    }

    // Create blob and download
    const blob = new Blob([content], { type: 'text/plain' });
    const objectUrl = URL.createObjectURL(blob);

    const filename = `${sanitizeFilename(courseName)}/_Links_and_Resources.txt`;

    return new Promise((resolve, reject) => {
        chrome.downloads.download({
            url: objectUrl,
            filename: filename,
            saveAs: false
        }, (downloadId) => {
            setTimeout(() => URL.revokeObjectURL(objectUrl), 60000);

            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            } else {
                resolve({
                    success: true,
                    downloadId,
                    filename
                });
            }
        });
    });
}

// ============================================================================
// PUBLIC API
// ============================================================================

/**
 * Downloads multiple files from course data
 * @param {Object} courseData - Course data object
 * @param {Array} selectedItems - Array of selected item IDs (or null for all)
 * @param {Function} onProgress - Progress callback
 * @returns {Promise<Object>} Download results
 */
export async function downloadFiles(courseData, selectedItems = null, onProgress = null) {
    console.log('[GCR Download] Starting batch download');

    // Reset state
    resetProgress();
    setProgressCallback(onProgress);

    const courseFolderName = sanitizeFilename(courseData.courseName || 'Downloads');
    const results = {
        success: [],
        failed: [],
        skipped: []
    };

    // Collect all downloadable attachments
    const allAttachments = [];
    const links = [];

    const collectAttachments = (items, sourceType) => {
        for (const item of items || []) {
            for (const attachment of item.attachments || []) {
                // Skip if selection is provided and item is not selected
                if (selectedItems && !selectedItems.includes(attachment.id)) {
                    continue;
                }

                if (attachment.isLink) {
                    links.push({
                        ...attachment,
                        parentTitle: item.title,
                        sourceType
                    });
                } else {
                    allAttachments.push({
                        ...attachment,
                        parentTitle: item.title,
                        sourceType
                    });
                }
            }
        }
    };

    collectAttachments(courseData.assignments, 'assignment');
    collectAttachments(courseData.materials, 'material');
    collectAttachments(courseData.announcements, 'announcement');

    // Add standalone links if any
    if (courseData.links) {
        for (const link of courseData.links) {
            if (!selectedItems || selectedItems.includes(link.id || link.url)) {
                links.push(link);
            }
        }
    }

    // Set total count
    downloadProgress.total = allAttachments.length + (links.length > 0 ? 1 : 0);
    updateProgress();

    console.log('[GCR Download] Files to download:', allAttachments.length);
    console.log('[GCR Download] Links to save:', links.length);

    // Download all files
    const downloadPromises = allAttachments.map(attachment =>
        queueDownload(attachment, courseFolderName)
            .then(result => {
                if (result.success) {
                    results.success.push({ ...attachment, ...result });
                } else if (result.skipped) {
                    results.skipped.push({ ...attachment, reason: result.error });
                }
                return result;
            })
            .catch(error => {
                results.failed.push({ ...attachment, error: error.message });
                return { success: false, error: error.message };
            })
    );

    // Wait for all downloads
    await Promise.all(downloadPromises);

    // Create resources file if there are links
    if (links.length > 0) {
        try {
            const resourcesResult = await createResourcesFile(links, courseData.courseName);
            if (resourcesResult.success && !resourcesResult.skipped) {
                results.success.push({
                    title: '_Links_and_Resources.txt',
                    type: 'resources',
                    ...resourcesResult
                });
            }
            downloadProgress.completed++;
            updateProgress();
        } catch (error) {
            console.error('[GCR Download] Error creating resources file:', error);
            results.failed.push({
                title: '_Links_and_Resources.txt',
                type: 'resources',
                error: error.message
            });
            downloadProgress.failed++;
            updateProgress();
        }
    }

    console.log('[GCR Download] Download complete:', {
        success: results.success.length,
        failed: results.failed.length,
        skipped: results.skipped.length
    });

    return results;
}

/**
 * Cancels all pending downloads
 */
export function cancelDownloads() {
    console.log('[GCR Download] Cancelling downloads');
    abortDownloads = true;
    downloadQueue = [];
}

/**
 * Gets download statistics
 * @returns {Object} Download stats
 */
export function getDownloadStats() {
    return {
        ...downloadProgress,
        queueLength: downloadQueue.length,
        activeDownloads
    };
}

console.log('[GCR] Download module loaded');
