/**
 * GCR Downloader - Authentication Module
 * Handles OAuth 2.0 flow with Google using chrome.identity API
 * 
 * Features:
 * - Token acquisition via chrome.identity.getAuthToken
 * - Token caching and refresh
 * - Automatic expiration handling (2-3 hour university sessions)
 * - Sign out / token revocation
 */

import { getStorage, setStorage, removeStorage } from './helpers.js';

// ============================================================================
// CONSTANTS
// ============================================================================

/**
 * Storage key for auth token data
 */
const AUTH_TOKEN_KEY = 'gcr_auth_token';
const AUTH_TIMESTAMP_KEY = 'gcr_auth_timestamp';

/**
 * Token expiry buffer - refresh 5 minutes before actual expiry
 * University accounts typically expire every 2-3 hours
 */
const TOKEN_EXPIRY_BUFFER_MS = 5 * 60 * 1000; // 5 minutes

/**
 * Default token lifetime assumption (1 hour, but may be shorter for university accounts)
 */
const DEFAULT_TOKEN_LIFETIME_MS = 60 * 60 * 1000; // 1 hour

// ============================================================================
// TOKEN MANAGEMENT
// ============================================================================

/**
 * Gets the current auth token, refreshing if necessary
 * @param {boolean} interactive - Whether to show login popup if needed
 * @returns {Promise<string>} Access token
 * @throws {Error} If authentication fails
 */
export async function getAuthToken(interactive = true) {
    console.log('[GCR Auth] Getting auth token, interactive:', interactive);

    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive }, async (token) => {
            if (chrome.runtime.lastError) {
                const error = chrome.runtime.lastError;
                console.error('[GCR Auth] Error getting token:', error.message);

                // Handle specific error cases
                if (error.message.includes('canceled')) {
                    reject(new Error('Authentication canceled by user'));
                } else if (error.message.includes('network')) {
                    reject(new Error('Network error during authentication'));
                } else if (error.message.includes('OAuth2')) {
                    reject(new Error('OAuth configuration error. Please check manifest.json'));
                } else {
                    reject(new Error(error.message));
                }
                return;
            }

            if (!token) {
                console.error('[GCR Auth] No token returned');
                reject(new Error('No authentication token received'));
                return;
            }

            console.log('[GCR Auth] Token obtained successfully');

            // Store token timestamp for expiry tracking
            try {
                await setStorage({
                    [AUTH_TOKEN_KEY]: token,
                    [AUTH_TIMESTAMP_KEY]: Date.now()
                });
            } catch (e) {
                console.warn('[GCR Auth] Failed to store token timestamp:', e);
            }

            resolve(token);
        });
    });
}

/**
 * Checks if user is currently authenticated (has valid token)
 * @returns {Promise<boolean>} True if authenticated
 */
export async function isAuthenticated() {
    try {
        // Try to get token non-interactively
        const token = await getAuthToken(false);
        return !!token;
    } catch (e) {
        console.log('[GCR Auth] Not authenticated:', e.message);
        return false;
    }
}

/**
 * Checks if the current token might be expired
 * Based on stored timestamp and configured lifetime
 * @returns {Promise<boolean>} True if token might be expired
 */
export async function isTokenExpired() {
    try {
        const data = await getStorage([AUTH_TIMESTAMP_KEY]);
        const timestamp = data[AUTH_TIMESTAMP_KEY];

        if (!timestamp) {
            // No timestamp stored, assume not expired but get fresh token
            return true;
        }

        const elapsed = Date.now() - timestamp;
        // Consider expired if older than lifetime minus buffer
        return elapsed > (DEFAULT_TOKEN_LIFETIME_MS - TOKEN_EXPIRY_BUFFER_MS);
    } catch (e) {
        console.warn('[GCR Auth] Error checking token expiry:', e);
        return true; // Assume expired on error
    }
}

/**
 * Forces a token refresh by removing cached token and getting new one
 * @param {boolean} interactive - Whether to show login popup
 * @returns {Promise<string>} New access token
 */
export async function refreshToken(interactive = true) {
    console.log('[GCR Auth] Forcing token refresh');

    // First, revoke the cached token
    try {
        await revokeTokenInternal(false);
    } catch (e) {
        console.warn('[GCR Auth] Error revoking old token:', e);
    }

    // Get new token
    return getAuthToken(interactive);
}

/**
 * Internal token revocation without clearing all storage
 * @param {boolean} revokeOnGoogle - Whether to revoke on Google's servers
 */
async function revokeTokenInternal(revokeOnGoogle = true) {
    return new Promise((resolve, reject) => {
        chrome.identity.getAuthToken({ interactive: false }, async (token) => {
            if (chrome.runtime.lastError || !token) {
                // No token to revoke
                resolve();
                return;
            }

            // Remove cached token from Chrome
            chrome.identity.removeCachedAuthToken({ token }, async () => {
                if (chrome.runtime.lastError) {
                    console.warn('[GCR Auth] Error removing cached token:', chrome.runtime.lastError);
                }

                // Optionally revoke on Google's servers
                if (revokeOnGoogle) {
                    try {
                        await fetch(`https://accounts.google.com/o/oauth2/revoke?token=${token}`);
                        console.log('[GCR Auth] Token revoked on Google servers');
                    } catch (e) {
                        console.warn('[GCR Auth] Failed to revoke token on Google:', e);
                    }
                }

                resolve();
            });
        });
    });
}

/**
 * Signs out the user by revoking token and clearing auth storage
 * @returns {Promise<void>}
 */
export async function signOut() {
    console.log('[GCR Auth] Signing out user');

    try {
        // Revoke token
        await revokeTokenInternal(true);

        // Clear stored auth data
        await removeStorage([AUTH_TOKEN_KEY, AUTH_TIMESTAMP_KEY]);

        console.log('[GCR Auth] Sign out complete');
    } catch (e) {
        console.error('[GCR Auth] Error during sign out:', e);
        throw e;
    }
}

// ============================================================================
// TOKEN VALIDATION
// ============================================================================

/**
 * Validates a token by making a test API request
 * @param {string} token - Token to validate
 * @returns {Promise<boolean>} True if token is valid
 */
export async function validateToken(token) {
    if (!token) return false;

    try {
        const response = await fetch(
            'https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=' + token
        );

        if (response.ok) {
            const data = await response.json();
            console.log('[GCR Auth] Token valid, expires in:', data.expires_in, 'seconds');
            return true;
        }

        console.log('[GCR Auth] Token validation failed:', response.status);
        return false;
    } catch (e) {
        console.error('[GCR Auth] Token validation error:', e);
        return false;
    }
}

/**
 * Gets auth token with automatic validation and refresh if needed
 * @param {boolean} interactive - Whether to show login popup
 * @returns {Promise<string>} Valid access token
 */
export async function getValidToken(interactive = true) {
    // Check if token might be expired
    const mightBeExpired = await isTokenExpired();

    if (mightBeExpired) {
        console.log('[GCR Auth] Token might be expired, refreshing...');
        return refreshToken(interactive);
    }

    // Get current token
    const token = await getAuthToken(interactive);

    // Validate it
    const isValid = await validateToken(token);

    if (!isValid) {
        console.log('[GCR Auth] Token invalid, refreshing...');
        return refreshToken(interactive);
    }

    return token;
}

// ============================================================================
// ERROR HANDLING
// ============================================================================

/**
 * Checks if an error indicates authentication is needed
 * @param {Error|Response} error - Error or response to check
 * @returns {boolean} True if re-authentication is needed
 */
export function isAuthError(error) {
    if (error instanceof Response) {
        return error.status === 401;
    }

    if (error instanceof Error) {
        const msg = error.message.toLowerCase();
        return msg.includes('401') ||
            msg.includes('unauthorized') ||
            msg.includes('token') ||
            msg.includes('auth');
    }

    return false;
}

/**
 * Handles an authentication error by prompting for re-auth
 * @param {boolean} interactive - Whether to show login popup
 * @returns {Promise<string>} New token after re-auth
 */
export async function handleAuthError(interactive = true) {
    console.log('[GCR Auth] Handling auth error, attempting re-authentication');
    return refreshToken(interactive);
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * Gets the user's email from the current session
 * @returns {Promise<string|null>} User email or null
 */
export async function getUserEmail() {
    try {
        const token = await getAuthToken(false);
        if (!token) return null;

        const response = await fetch(
            'https://www.googleapis.com/oauth2/v1/userinfo?access_token=' + token
        );

        if (response.ok) {
            const data = await response.json();
            return data.email;
        }

        return null;
    } catch (e) {
        console.error('[GCR Auth] Error getting user email:', e);
        return null;
    }
}

console.log('[GCR] Auth module loaded');
