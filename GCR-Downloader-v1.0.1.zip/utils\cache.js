/**
 * GCR Downloader - Cache Management Module
 * Handles course data caching with smart invalidation
 * 
 * Key Features:
 * - Single course caching (only last visited course)
 * - Automatic cache clearing on course change
 * - Persistence across page refreshes and browser sessions
 * - Cache size management (max 5MB limit)
 */

import { getStorage, setStorage, removeStorage } from './helpers.js';

// ============================================================================
// CONSTANTS
// ============================================================================

/**
 * Storage keys for cache data
 */
const KEYS = {
    LAST_COURSE_ID: 'gcr_last_course_id',           // Currently cached course ID
    LAST_COURSE_NAME: 'gcr_last_course_name',       // Cached course name
    COURSE_DATA_PREFIX: 'gcr_course_data_',         // Prefix for course data
    CACHE_TIMESTAMP: 'gcr_cache_timestamp',          // When cache was created
    FETCH_IN_PROGRESS: 'gcr_fetch_in_progress'      // Flag for in-progress fetch
};

/**
 * Maximum cache age in milliseconds (30 days)
 */
const MAX_CACHE_AGE_MS = 30 * 24 * 60 * 60 * 1000;

/**
 * Maximum cache size in bytes (5MB)
 */
const MAX_CACHE_SIZE_BYTES = 5 * 1024 * 1024;

// ============================================================================
// CORE CACHE OPERATIONS
// ============================================================================

/**
 * Gets the ID of the last visited/cached course
 * @returns {Promise<string|null>} Course ID or null if no course cached
 */
export async function getLastCourseId() {
    try {
        const data = await getStorage(KEYS.LAST_COURSE_ID);
        return data[KEYS.LAST_COURSE_ID] || null;
    } catch (e) {
        console.error('[GCR Cache] Error getting last course ID:', e);
        return null;
    }
}

/**
 * Gets the name of the last visited/cached course
 * @returns {Promise<string|null>} Course name or null
 */
export async function getLastCourseName() {
    try {
        const data = await getStorage(KEYS.LAST_COURSE_NAME);
        return data[KEYS.LAST_COURSE_NAME] || null;
    } catch (e) {
        console.error('[GCR Cache] Error getting last course name:', e);
        return null;
    }
}

/**
 * Sets the current course as the last visited course
 * Also clears any previously cached course data
 * @param {string} courseId - Course ID to cache
 * @param {string} courseName - Course name to cache
 * @returns {Promise<void>}
 */
export async function setLastCourse(courseId, courseName) {
    if (!courseId) {
        console.warn('[GCR Cache] Attempted to set null course ID');
        return;
    }

    console.log('[GCR Cache] Setting last course:', courseId, courseName);

    try {
        // Get the previous course ID
        const previousCourseId = await getLastCourseId();

        // If switching to a different course, clear old cache
        if (previousCourseId && previousCourseId !== courseId) {
            console.log('[GCR Cache] Course changed, clearing old cache for:', previousCourseId);
            await clearCourseData(previousCourseId);
        }

        // Set the new course as current
        await setStorage({
            [KEYS.LAST_COURSE_ID]: courseId,
            [KEYS.LAST_COURSE_NAME]: courseName || 'Unknown Course',
            [KEYS.CACHE_TIMESTAMP]: Date.now()
        });

        console.log('[GCR Cache] Last course updated successfully');
    } catch (e) {
        console.error('[GCR Cache] Error setting last course:', e);
        throw e;
    }
}

/**
 * Gets cached course data for a specific course
 * @param {string} courseId - Course ID to get data for
 * @returns {Promise<Object|null>} Course data or null if not cached
 */
export async function getCourseData(courseId) {
    if (!courseId) return null;

    const key = KEYS.COURSE_DATA_PREFIX + courseId;

    try {
        const data = await getStorage(key);
        const courseData = data[key];

        if (!courseData) {
            console.log('[GCR Cache] No cached data for course:', courseId);
            return null;
        }

        // Check if cache is too old
        if (courseData.timestamp && Date.now() - courseData.timestamp > MAX_CACHE_AGE_MS) {
            console.log('[GCR Cache] Cache expired for course:', courseId);
            await clearCourseData(courseId);
            return null;
        }

        console.log('[GCR Cache] Retrieved cached data for course:', courseId);
        return courseData;
    } catch (e) {
        console.error('[GCR Cache] Error getting course data:', e);
        return null;
    }
}

/**
 * Gets cached data for the last visited course
 * @returns {Promise<Object|null>} Course data or null
 */
export async function getLastCourseData() {
    const courseId = await getLastCourseId();
    if (!courseId) return null;
    return getCourseData(courseId);
}

/**
 * Sets/updates cached course data
 * @param {string} courseId - Course ID
 * @param {Object} data - Data to cache (materials, assignments, etc.)
 * @returns {Promise<void>}
 */
export async function setCourseData(courseId, data) {
    if (!courseId) {
        console.warn('[GCR Cache] Attempted to set data for null course ID');
        return;
    }

    const key = KEYS.COURSE_DATA_PREFIX + courseId;

    // Add metadata
    const cacheData = {
        ...data,
        courseId,
        timestamp: Date.now(),
        version: 1
    };

    // Check size before storing
    const dataString = JSON.stringify(cacheData);
    if (dataString.length > MAX_CACHE_SIZE_BYTES) {
        console.warn('[GCR Cache] Data too large to cache:', dataString.length, 'bytes');
        // Try to store a trimmed version
        cacheData.materials = cacheData.materials?.slice(0, 100);
        cacheData.assignments = cacheData.assignments?.slice(0, 100);
        cacheData.announcements = cacheData.announcements?.slice(0, 50);
        cacheData.trimmed = true;
    }

    try {
        await setStorage({ [key]: cacheData });
        console.log('[GCR Cache] Course data cached for:', courseId);
    } catch (e) {
        console.error('[GCR Cache] Error caching course data:', e);

        // If quota exceeded, try clearing old data
        if (e.message?.includes('QUOTA_BYTES')) {
            console.log('[GCR Cache] Storage quota exceeded, clearing old data');
            await clearAllCourseData();
            // Retry once
            try {
                await setStorage({ [key]: cacheData });
            } catch (retryError) {
                console.error('[GCR Cache] Still failed after clearing:', retryError);
                throw retryError;
            }
        } else {
            throw e;
        }
    }
}

/**
 * Clears cached data for a specific course
 * @param {string} courseId - Course ID to clear
 * @returns {Promise<void>}
 */
export async function clearCourseData(courseId) {
    if (!courseId) return;

    const key = KEYS.COURSE_DATA_PREFIX + courseId;

    try {
        await removeStorage(key);
        console.log('[GCR Cache] Cleared data for course:', courseId);
    } catch (e) {
        console.error('[GCR Cache] Error clearing course data:', e);
    }
}

/**
 * Clears all cached course data and resets to fresh state
 * @returns {Promise<void>}
 */
export async function clearAllCourseData() {
    console.log('[GCR Cache] Clearing all cached data');

    try {
        // Get all storage to find course data keys
        const allData = await getStorage(null);
        const keysToRemove = Object.keys(allData).filter(key =>
            key.startsWith(KEYS.COURSE_DATA_PREFIX)
        );

        if (keysToRemove.length > 0) {
            await removeStorage(keysToRemove);
        }

        console.log('[GCR Cache] All course data cleared');
    } catch (e) {
        console.error('[GCR Cache] Error clearing all data:', e);
    }
}

/**
 * Completely resets the cache (including last course info)
 * @returns {Promise<void>}
 */
export async function resetCache() {
    console.log('[GCR Cache] Resetting entire cache');

    try {
        await clearAllCourseData();
        await removeStorage([
            KEYS.LAST_COURSE_ID,
            KEYS.LAST_COURSE_NAME,
            KEYS.CACHE_TIMESTAMP,
            KEYS.FETCH_IN_PROGRESS
        ]);
        console.log('[GCR Cache] Cache reset complete');
    } catch (e) {
        console.error('[GCR Cache] Error resetting cache:', e);
    }
}

// ============================================================================
// FETCH STATE MANAGEMENT
// ============================================================================

/**
 * Marks that a fetch is in progress for a course
 * Used to prevent duplicate fetches
 * @param {string} courseId - Course being fetched
 * @returns {Promise<void>}
 */
export async function setFetchInProgress(courseId) {
    await setStorage({
        [KEYS.FETCH_IN_PROGRESS]: {
            courseId,
            startTime: Date.now()
        }
    });
}

/**
 * Clears the fetch in progress flag
 * @returns {Promise<void>}
 */
export async function clearFetchInProgress() {
    await removeStorage(KEYS.FETCH_IN_PROGRESS);
}

/**
 * Checks if a fetch is currently in progress
 * @returns {Promise<Object|null>} Fetch info or null
 */
export async function getFetchInProgress() {
    try {
        const data = await getStorage(KEYS.FETCH_IN_PROGRESS);
        const fetchInfo = data[KEYS.FETCH_IN_PROGRESS];

        if (!fetchInfo) return null;

        // Clear stale fetch flags (older than 2 minutes)
        if (Date.now() - fetchInfo.startTime > 2 * 60 * 1000) {
            await clearFetchInProgress();
            return null;
        }

        return fetchInfo;
    } catch (e) {
        return null;
    }
}

// ============================================================================
// CACHE STATISTICS
// ============================================================================

/**
 * Gets cache statistics for debugging/display
 * @returns {Promise<Object>} Cache stats
 */
export async function getCacheStats() {
    try {
        const allData = await getStorage(null);

        const courseDataKeys = Object.keys(allData).filter(key =>
            key.startsWith(KEYS.COURSE_DATA_PREFIX)
        );

        let totalSize = 0;
        for (const key of Object.keys(allData)) {
            totalSize += JSON.stringify(allData[key]).length;
        }

        return {
            lastCourseId: allData[KEYS.LAST_COURSE_ID] || null,
            lastCourseName: allData[KEYS.LAST_COURSE_NAME] || null,
            cacheTimestamp: allData[KEYS.CACHE_TIMESTAMP] || null,
            cachedCourses: courseDataKeys.length,
            totalSizeBytes: totalSize,
            totalSizeFormatted: formatBytes(totalSize),
            maxSize: MAX_CACHE_SIZE_BYTES,
            usagePercent: Math.round((totalSize / MAX_CACHE_SIZE_BYTES) * 100)
        };
    } catch (e) {
        console.error('[GCR Cache] Error getting stats:', e);
        return {
            error: e.message
        };
    }
}

/**
 * Formats bytes to human-readable string
 * @param {number} bytes - Bytes to format
 * @returns {string} Formatted string
 */
function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// ============================================================================
// COURSE CHANGE DETECTION HELPERS
// ============================================================================

/**
 * Checks if current course is different from cached course
 * @param {string} currentCourseId - Current course ID from URL
 * @returns {Promise<boolean>} True if course changed
 */
export async function hasCourseChanged(currentCourseId) {
    const lastCourseId = await getLastCourseId();

    // No previous course = new course
    if (!lastCourseId) return true;

    // Same course = no change
    if (lastCourseId === currentCourseId) return false;

    // Different course = change
    return true;
}

/**
 * Handles a course change by clearing old data and setting new course
 * @param {string} newCourseId - New course ID
 * @param {string} newCourseName - New course name
 * @returns {Promise<void>}
 */
export async function handleCourseChange(newCourseId, newCourseName) {
    console.log('[GCR Cache] Handling course change to:', newCourseId);

    // This will clear old course data and set new course
    await setLastCourse(newCourseId, newCourseName);
}

/**
 * Gets the total count of downloadable items in cached data
 * @returns {Promise<number>} Total count
 */
export async function getCachedItemCount() {
    const data = await getLastCourseData();

    if (!data) return 0;

    let count = 0;
    if (data.materials) count += data.materials.length;
    if (data.assignments) count += data.assignments.length;
    if (data.announcements) count += data.announcements.length;
    if (data.links) count += data.links.length;

    return count;
}

console.log('[GCR] Cache module loaded');
