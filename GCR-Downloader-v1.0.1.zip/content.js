/**
 * GCR Downloader - Content Script
 * Injects floating download button and handles course detection
 * 
 * Features:
 * - Always-visible floating button (bottom-right)
 * - Course detection from URL
 * - Badge showing downloadable item count
 * - State management for course switching
 */

// ============================================================================
// CONSTANTS
// ============================================================================

const BUTTON_ID = 'gcr-downloader-button';
const BADGE_ID = 'gcr-downloader-badge';
const DETECTION_DEBOUNCE_MS = 500;

// ============================================================================
// STATE
// ============================================================================

let lastCourseId = null;
let lastUrl = '';
let detectionTimeout = null;
let isLoading = false;
let currentItemCount = 0;

// ============================================================================
// BUTTON CREATION & MANAGEMENT
// ============================================================================

/**
 * Creates and injects the floating download button
 */
function createDownloadButton() {
    // Remove existing button if any
    const existing = document.getElementById(BUTTON_ID);
    if (existing) {
        existing.remove();
    }

    // Create button container
    const button = document.createElement('div');
    button.id = BUTTON_ID;
    button.className = 'gcr-download-button';
    button.innerHTML = `
    <div class="gcr-button-content">
      <svg class="gcr-download-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
      <span class="gcr-button-text">Download</span>
      <span id="${BADGE_ID}" class="gcr-badge gcr-badge-hidden">0</span>
    </div>
    <div class="gcr-loading-spinner gcr-hidden">
      <div class="gcr-spinner"></div>
    </div>
  `;

    // Add click handler
    button.addEventListener('click', handleButtonClick);

    // Inject into page
    document.body.appendChild(button);

    console.log('[GCR Content] Download button injected');
}

/**
 * Updates the badge count on the button
 * @param {number|string} count - Count to display
 * @param {boolean} loading - Whether to show loading state
 */
function updateBadge(count, loading = false) {
    const badge = document.getElementById(BADGE_ID);
    const button = document.getElementById(BUTTON_ID);

    if (!badge || !button) return;

    const spinner = button.querySelector('.gcr-loading-spinner');
    const content = button.querySelector('.gcr-button-content');

    if (loading) {
        isLoading = true;
        badge.classList.add('gcr-badge-hidden');
        spinner?.classList.remove('gcr-hidden');
        content?.classList.add('gcr-loading');
        button.classList.add('gcr-loading');
    } else {
        isLoading = false;
        spinner?.classList.add('gcr-hidden');
        content?.classList.remove('gcr-loading');
        button.classList.remove('gcr-loading');

        if (count > 0) {
            badge.textContent = count > 99 ? '99+' : count.toString();
            badge.classList.remove('gcr-badge-hidden');
            currentItemCount = typeof count === 'number' ? count : parseInt(count) || 0;
        } else {
            badge.classList.add('gcr-badge-hidden');
            currentItemCount = 0;
        }
    }
}

/**
 * Shows an error state on the button (temporary)
 * @param {string} message - Error message
 */
function showButtonError(message) {
    const button = document.getElementById(BUTTON_ID);
    if (!button) return;

    button.classList.add('gcr-error');

    setTimeout(() => {
        button?.classList.remove('gcr-error');
    }, 3000);
}

// ============================================================================
// BUTTON CLICK HANDLER
// ============================================================================

/**
 * Handles download button click
 */
async function handleButtonClick() {
    console.log('[GCR Content] Button clicked');

    if (isLoading) {
        console.log('[GCR Content] Loading in progress, ignoring click');
        return;
    }

    // Send message to open popup
    try {
        const response = await sendMessage({ type: 'GET_CACHED_DATA' });

        if (!response.success) {
            console.error('[GCR Content] Failed to get cached data:', response.error);
            showNotification('Error loading data. Please try again.', 'error');
            return;
        }

        if (!response.data) {
            // No data cached - show message
            showNotification('No course data yet. Visit a course to start!', 'info');
            return;
        }

        // Open the popup with course data
        openPopup(response.data);

    } catch (error) {
        console.error('[GCR Content] Error handling click:', error);
        showNotification('Error: ' + error.message, 'error');
    }
}

// ============================================================================
// POPUP MODAL
// ============================================================================

/**
 * Opens the download selection popup
 * @param {Object} courseData - Course data to display
 */
function openPopup(courseData) {
    // Remove existing popup
    closePopup();

    // Create popup overlay
    const overlay = document.createElement('div');
    overlay.id = 'gcr-popup-overlay';
    overlay.className = 'gcr-popup-overlay';

    // Create popup content
    const popup = document.createElement('div');
    popup.className = 'gcr-popup';

    // Build content
    const totalItems = countDownloadableItems(courseData);
    const categories = categorizeItems(courseData);

    popup.innerHTML = `
    <div class="gcr-popup-header">
      <div class="gcr-popup-title">
        <h2>📚 ${escapeHtml(courseData.courseName || 'Course Materials')}</h2>
        <span class="gcr-popup-count">${totalItems} items</span>
      </div>
      <button class="gcr-popup-close" id="gcr-popup-close">&times;</button>
    </div>
    
    <div class="gcr-popup-toolbar">
      <div class="gcr-select-buttons">
        <button class="gcr-btn gcr-btn-secondary" id="gcr-select-all">Select All</button>
        <button class="gcr-btn gcr-btn-secondary" id="gcr-deselect-all">Deselect All</button>
      </div>
      <div class="gcr-search-container">
        <input type="text" class="gcr-search-input" id="gcr-search" placeholder="Search files...">
      </div>
    </div>
    
    <div class="gcr-popup-content" id="gcr-popup-content">
      ${renderCategories(categories)}
    </div>
    
    <div class="gcr-popup-footer">
      <div class="gcr-selected-count">
        <span id="gcr-selected-count">0</span> selected
      </div>
      <div class="gcr-popup-actions">
        <button class="gcr-btn gcr-btn-secondary" id="gcr-refresh-btn">
          🔄 Refresh
        </button>
        <button class="gcr-btn gcr-btn-primary" id="gcr-download-btn">
          ⬇️ Download Selected
        </button>
      </div>
    </div>
    
    <div class="gcr-progress-container gcr-hidden" id="gcr-progress-container">
      <div class="gcr-progress-text" id="gcr-progress-text">Downloading...</div>
      <div class="gcr-progress-bar">
        <div class="gcr-progress-fill" id="gcr-progress-fill"></div>
      </div>
      <button class="gcr-btn gcr-btn-danger gcr-btn-small" id="gcr-cancel-download">Cancel</button>
    </div>
  `;

    overlay.appendChild(popup);
    document.body.appendChild(overlay);

    // Attach event listeners
    attachPopupListeners(courseData);

    // Update selected count
    updateSelectedCount();
}

/**
 * Closes the popup
 */
function closePopup() {
    const overlay = document.getElementById('gcr-popup-overlay');
    if (overlay) {
        overlay.remove();
    }
}

/**
 * Counts downloadable items in course data
 * @param {Object} data - Course data
 * @returns {number} Total count
 */
function countDownloadableItems(data) {
    let count = 0;

    const countInItems = (items) => {
        for (const item of items || []) {
            count += (item.attachments || []).length;
        }
    };

    countInItems(data.assignments);
    countInItems(data.materials);
    countInItems(data.announcements);

    return count;
}

/**
 * Categorizes items by type
 * @param {Object} data - Course data
 * @returns {Object} Categorized items
 */
function categorizeItems(data) {
    return {
        assignments: {
            title: '📝 Assignments',
            items: data.assignments || [],
            icon: '📝'
        },
        materials: {
            title: '📖 Materials & Slides',
            items: data.materials || [],
            icon: '📖'
        },
        announcements: {
            title: '📢 Announcements',
            items: data.announcements || [],
            icon: '📢'
        }
    };
}

/**
 * Renders category sections
 * @param {Object} categories - Categorized items
 * @returns {string} HTML string
 */
function renderCategories(categories) {
    let html = '';

    for (const [key, category] of Object.entries(categories)) {
        if (!category.items || category.items.length === 0) continue;

        const attachmentCount = category.items.reduce((sum, item) =>
            sum + (item.attachments?.length || 0), 0
        );

        if (attachmentCount === 0) continue;

        html += `
      <div class="gcr-category" data-category="${key}">
        <div class="gcr-category-header">
          <span class="gcr-category-title">${category.title}</span>
          <span class="gcr-category-count">${attachmentCount} files</span>
        </div>
        <div class="gcr-category-items">
          ${renderCategoryItems(category.items)}
        </div>
      </div>
    `;
    }

    if (!html) {
        html = `
      <div class="gcr-empty-state">
        <div class="gcr-empty-icon">📭</div>
        <p>No downloadable files found in this course.</p>
      </div>
    `;
    }

    return html;
}

/**
 * Renders items within a category
 * @param {Array} items - Items array
 * @returns {string} HTML string
 */
function renderCategoryItems(items) {
    let html = '';

    for (const item of items) {
        if (!item.attachments || item.attachments.length === 0) continue;

        html += `
      <div class="gcr-item">
        <div class="gcr-item-header">${escapeHtml(item.title)}</div>
        <div class="gcr-attachments">
          ${renderAttachments(item.attachments)}
        </div>
      </div>
    `;
    }

    return html;
}

/**
 * Renders attachment checkboxes
 * @param {Array} attachments - Attachments array
 * @returns {string} HTML string
 */
function renderAttachments(attachments) {
    let html = '';

    for (const attachment of attachments) {
        const icon = getAttachmentIcon(attachment);
        const id = attachment.id || attachment.url || Math.random().toString(36);
        const isLink = attachment.isLink;
        const typeLabel = isLink ? `(${attachment.type})` : '';

        html += `
      <label class="gcr-attachment" data-id="${escapeHtml(id)}" data-is-link="${isLink}">
        <input type="checkbox" class="gcr-checkbox" value="${escapeHtml(id)}" checked>
        <span class="gcr-attachment-icon">${icon}</span>
        <span class="gcr-attachment-title">${escapeHtml(attachment.title)} ${typeLabel}</span>
      </label>
    `;
    }

    return html;
}

/**
 * Gets icon for attachment type
 * @param {Object} attachment - Attachment object
 * @returns {string} Emoji icon
 */
function getAttachmentIcon(attachment) {
    if (attachment.type === 'youtube') return '▶️';
    if (attachment.type === 'form') return '📋';
    if (attachment.type === 'link') return '🔗';

    const mimeType = attachment.mimeType || '';
    if (mimeType.includes('pdf')) return '📄';
    if (mimeType.includes('document') || mimeType.includes('word')) return '📝';
    if (mimeType.includes('spreadsheet') || mimeType.includes('excel')) return '📊';
    if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) return '📽️';
    if (mimeType.includes('image')) return '🖼️';
    if (mimeType.includes('video')) return '🎬';
    if (mimeType.includes('audio')) return '🎵';

    return '📁';
}

/**
 * Attaches event listeners to popup
 * @param {Object} courseData - Course data
 */
function attachPopupListeners(courseData) {
    // Close button
    document.getElementById('gcr-popup-close')?.addEventListener('click', closePopup);

    // Click outside to close
    document.getElementById('gcr-popup-overlay')?.addEventListener('click', (e) => {
        if (e.target.id === 'gcr-popup-overlay') {
            closePopup();
        }
    });

    // Escape key to close
    const escHandler = (e) => {
        if (e.key === 'Escape') {
            closePopup();
            document.removeEventListener('keydown', escHandler);
        }
    };
    document.addEventListener('keydown', escHandler);

    // Select all
    document.getElementById('gcr-select-all')?.addEventListener('click', () => {
        document.querySelectorAll('.gcr-checkbox').forEach(cb => {
            cb.checked = true;
        });
        updateSelectedCount();
    });

    // Deselect all
    document.getElementById('gcr-deselect-all')?.addEventListener('click', () => {
        document.querySelectorAll('.gcr-checkbox').forEach(cb => {
            cb.checked = false;
        });
        updateSelectedCount();
    });

    // Search
    document.getElementById('gcr-search')?.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        document.querySelectorAll('.gcr-attachment').forEach(el => {
            const title = el.querySelector('.gcr-attachment-title')?.textContent?.toLowerCase() || '';
            el.style.display = title.includes(query) ? '' : 'none';
        });
    });

    // Checkbox changes
    document.querySelectorAll('.gcr-checkbox').forEach(cb => {
        cb.addEventListener('change', updateSelectedCount);
    });

    // Refresh button
    document.getElementById('gcr-refresh-btn')?.addEventListener('click', async () => {
        closePopup();
        const courseId = getCurrentCourseId();
        if (courseId) {
            await fetchCourseData(courseId);
        }
    });

    // Download button
    document.getElementById('gcr-download-btn')?.addEventListener('click', () => {
        startDownload();
    });

    // Cancel download
    document.getElementById('gcr-cancel-download')?.addEventListener('click', () => {
        cancelDownload();
    });
}

/**
 * Updates the selected count display
 */
function updateSelectedCount() {
    const checked = document.querySelectorAll('.gcr-checkbox:checked').length;
    const countEl = document.getElementById('gcr-selected-count');
    if (countEl) {
        countEl.textContent = checked.toString();
    }
}

/**
 * Starts the download process
 */
async function startDownload() {
    const selected = Array.from(document.querySelectorAll('.gcr-checkbox:checked'))
        .map(cb => cb.value);

    if (selected.length === 0) {
        showNotification('Please select at least one file to download.', 'warning');
        return;
    }

    // Show progress
    const progressContainer = document.getElementById('gcr-progress-container');
    const downloadBtn = document.getElementById('gcr-download-btn');
    const refreshBtn = document.getElementById('gcr-refresh-btn');

    progressContainer?.classList.remove('gcr-hidden');
    if (downloadBtn) downloadBtn.disabled = true;
    if (refreshBtn) refreshBtn.disabled = true;

    try {
        const response = await sendMessage({
            type: 'DOWNLOAD_FILES',
            selectedItems: selected
        });

        if (response.success) {
            // Monitor progress
            await monitorDownloadProgress();

            showNotification(
                `Download complete! ${response.completed}/${response.total} files downloaded.`,
                response.failed > 0 ? 'warning' : 'success'
            );
        } else {
            showNotification('Download failed: ' + response.error, 'error');
        }
    } catch (error) {
        showNotification('Download error: ' + error.message, 'error');
    } finally {
        progressContainer?.classList.add('gcr-hidden');
        if (downloadBtn) downloadBtn.disabled = false;
        if (refreshBtn) refreshBtn.disabled = false;
    }
}

/**
 * Monitors download progress
 */
async function monitorDownloadProgress() {
    const progressFill = document.getElementById('gcr-progress-fill');
    const progressText = document.getElementById('gcr-progress-text');

    while (true) {
        const response = await sendMessage({ type: 'GET_DOWNLOAD_PROGRESS' });

        if (!response.success || !response.active) {
            break;
        }

        if (progressFill) {
            progressFill.style.width = `${response.percent}%`;
        }
        if (progressText) {
            progressText.textContent = `Downloading... ${response.completed}/${response.total}`;
        }

        await new Promise(r => setTimeout(r, 500));
    }
}

/**
 * Cancels the download
 */
async function cancelDownload() {
    await sendMessage({ type: 'CANCEL_DOWNLOADS' });
    showNotification('Download cancelled.', 'info');
}

// ============================================================================
// NOTIFICATIONS
// ============================================================================

/**
 * Shows a toast notification
 * @param {string} message - Message to show
 * @param {string} type - Type: success, error, warning, info
 */
function showNotification(message, type = 'info') {
    // Remove existing notification
    const existing = document.querySelector('.gcr-notification');
    if (existing) {
        existing.remove();
    }

    const notification = document.createElement('div');
    notification.className = `gcr-notification gcr-notification-${type}`;

    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };

    notification.innerHTML = `
    <span class="gcr-notification-icon">${icons[type] || icons.info}</span>
    <span class="gcr-notification-message">${escapeHtml(message)}</span>
  `;

    document.body.appendChild(notification);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        notification.classList.add('gcr-notification-hide');
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// ============================================================================
// COURSE DETECTION
// ============================================================================

/**
 * Decodes a base64-encoded course ID to numeric format
 * Google Classroom URLs use base64-encoded IDs, but the API needs numeric IDs
 * @param {string} encodedId - Base64 encoded course ID from URL
 * @returns {string} Numeric course ID for API
 */
function decodeCourseId(encodedId) {
    try {
        // Try to decode as base64
        const decoded = atob(encodedId);
        // Check if result is a valid number
        if (/^\d+$/.test(decoded)) {
            console.log('[GCR Content] Decoded course ID:', encodedId, '->', decoded);
            return decoded;
        }
    } catch (e) {
        // Not base64, might already be numeric
        console.log('[GCR Content] Course ID not base64, using as-is:', encodedId);
    }

    // If already numeric or decoding failed, return as-is
    return encodedId;
}

/**
 * Gets current course ID from URL
 * @returns {string|null} Course ID or null
 */
function getCurrentCourseId() {
    const url = window.location.href;

    // Pattern: /c/COURSE_ID or /u/X/c/COURSE_ID
    const match = url.match(/\/c\/([^\/\?]+)/);
    if (match) {
        const rawId = match[1];
        // Decode base64 to numeric ID for API
        return decodeCourseId(rawId);
    }

    return null;
}

/**
 * Checks if on main/dashboard page
 * @returns {boolean} True if on main page
 */
function isOnMainPage() {
    const path = window.location.pathname;
    return path === '/' ||
        path === '/u/0/' ||
        path === '/u/1/' ||
        path === '/h' ||
        /^\/u\/\d+\/?$/.test(path);
}

/**
 * Handles URL/course change detection
 */
function handleUrlChange() {
    const currentUrl = window.location.href;

    // Skip if URL hasn't changed
    if (currentUrl === lastUrl) return;
    lastUrl = currentUrl;

    // Clear any pending detection
    if (detectionTimeout) {
        clearTimeout(detectionTimeout);
    }

    // Debounce to handle rapid navigation
    detectionTimeout = setTimeout(async () => {
        const currentCourseId = getCurrentCourseId();

        console.log('[GCR Content] URL change detected:', {
            currentCourseId,
            lastCourseId,
            isMainPage: isOnMainPage()
        });

        if (currentCourseId) {
            // On a course page
            if (currentCourseId !== lastCourseId) {
                // New course - fetch data
                console.log('[GCR Content] New course detected, fetching data');
                lastCourseId = currentCourseId;
                await fetchCourseData(currentCourseId);
            }
        } else if (isOnMainPage()) {
            // On main page - keep last course data
            console.log('[GCR Content] On main page, retaining data');
            // Badge should still show last course's count
        }
    }, DETECTION_DEBOUNCE_MS);
}

/**
 * Fetches course data from API
 * @param {string} courseId - Course ID to fetch
 */
async function fetchCourseData(courseId) {
    console.log('[GCR Content] Fetching course data:', courseId);

    // Show loading state
    updateBadge(0, true);

    try {
        const response = await sendMessage({
            type: 'FETCH_COURSE_DATA',
            courseId
        });

        if (response.success && response.data) {
            console.log('[GCR Content] Course data fetched:', response.data.totalItems, 'items');
            updateBadge(response.data.totalItems);
        } else {
            console.error('[GCR Content] Fetch failed:', response.error);
            updateBadge(0);
            showNotification('Failed to load course data. ' + (response.error || ''), 'error');
        }
    } catch (error) {
        console.error('[GCR Content] Fetch error:', error);
        updateBadge(0);
        showNotification('Error loading course data.', 'error');
    }
}

// ============================================================================
// MESSAGE PASSING
// ============================================================================

/**
 * Sends a message to the background script
 * @param {Object} message - Message to send
 * @returns {Promise<Object>} Response
 */
function sendMessage(message) {
    return new Promise((resolve, reject) => {
        try {
            chrome.runtime.sendMessage(message, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(response || { success: false, error: 'No response' });
                }
            });
        } catch (error) {
            reject(error);
        }
    });
}

// ============================================================================
// UTILITIES
// ============================================================================

/**
 * Escapes HTML special characters
 * @param {string} str - String to escape
 * @returns {string} Escaped string
 */
function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// ============================================================================
// INITIALIZATION
// ============================================================================

/**
 * Sets up navigation detection
 */
function setupNavigationDetection() {
    // Method 1: History API interception
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;

    history.pushState = function (...args) {
        const result = originalPushState.apply(this, args);
        handleUrlChange();
        return result;
    };

    history.replaceState = function (...args) {
        const result = originalReplaceState.apply(this, args);
        handleUrlChange();
        return result;
    };

    // Method 2: popstate (back/forward)
    window.addEventListener('popstate', handleUrlChange);

    // Method 3: MutationObserver for SPA
    const observer = new MutationObserver(handleUrlChange);
    observer.observe(document.body, { childList: true, subtree: true });

    // Method 4: Polling fallback
    setInterval(handleUrlChange, 1000);

    console.log('[GCR Content] Navigation detection set up');
}

/**
 * Listen for messages from background (for multi-tab sync)
 */
function setupMessageListener() {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === 'COURSE_DATA_UPDATED') {
            console.log('[GCR Content] Received sync update:', message.courseId);

            // Update badge with new data
            if (message.courseId) {
                // Fetch the updated count
                sendMessage({ type: 'GET_ITEM_COUNT' }).then(response => {
                    if (response.success) {
                        updateBadge(response.count);
                    }
                }).catch(() => { });
            }
        }
        return true;
    });
}

/**
 * Sets up offline detection
 */
function setupOfflineDetection() {
    const updateOnlineStatus = () => {
        const button = document.getElementById(BUTTON_ID);
        if (!button) return;

        if (navigator.onLine) {
            button.classList.remove('gcr-offline');
            button.title = 'Download course materials';
        } else {
            button.classList.add('gcr-offline');
            button.title = 'Offline - downloads unavailable';
        }
    };

    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
    updateOnlineStatus();
}

/**
 * Initializes the content script
 */
async function init() {
    console.log('[GCR Content] Initializing...');

    // Inject button
    createDownloadButton();

    // Set up navigation detection
    setupNavigationDetection();

    // Set up multi-tab sync
    setupMessageListener();

    // Set up offline detection
    setupOfflineDetection();

    // Load cached data
    try {
        const response = await sendMessage({ type: 'GET_CACHED_DATA' });

        if (response.success && response.data) {
            console.log('[GCR Content] Loaded cached data:', response.data.totalItems, 'items');
            updateBadge(response.data.totalItems);
            lastCourseId = response.data.courseId;
        }
    } catch (error) {
        console.warn('[GCR Content] Failed to load cached data:', error);
    }

    // Initial course detection
    lastUrl = window.location.href;
    handleUrlChange();

    console.log('[GCR Content] Initialized');
}

// Run initialization when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

