# 📥 GCR Downloader - Google Classroom Material Downloader

A powerful Chrome Extension to download all materials from your Google Classroom courses with a single click. Perfect for university students!

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![Manifest](https://img.shields.io/badge/Manifest-V3-green.svg)
![License](https://img.shields.io/badge/license-MIT-blue.svg)

## ✨ Features

### 🎯 Core Features
- **Always-Visible Button**: Floating download button on every Google Classroom page
- **Smart Course Detection**: Automatically detects when you switch courses
- **Intelligent Caching**: Remembers last visited course data on dashboard
- **Batch Downloads**: Download multiple files with one click
- **File Type Support**: PDFs, Docs, Slides, Sheets, Images, Videos, and more
- **Multi-Tab Sync**: All tabs update when you switch courses
- **Offline Detection**: Graceful handling when network is unavailable

### 📁 Supported File Types

| File Type | Action | Output Format |
|-----------|--------|---------------|
| Google Docs | Export | PDF |
| Google Slides | Export | PDF |
| Google Sheets | Export | XLSX |
| Google Drawings | Export | PNG |
| Google Forms | Save Link | .txt |
| Regular PDFs | Download | PDF |
| PowerPoint | Download | PPTX |
| Word Docs | Download | DOCX |
| Images | Download | Original |
| YouTube Videos | Save Link | .txt |
| External Links | Save Link | .txt |

### 🔄 Smart Caching Behavior

```
Fresh Install → Button shows "Download" (no badge)
    ↓
Visit Course A → Loading... → Badge shows "[24]"
    ↓
Return to Dashboard → Badge still shows "[24]" (retained!)
    ↓
Visit Course B → Badge resets → Loading... → Badge shows "[18]"
    ↓
Return to Dashboard → Badge shows "[18]" (Course B data)
```

### 🔗 Multi-Tab Behavior

When you have multiple tabs open:
- **Tab 1:** Course A, **Tab 2:** Course B
- Cache stores the **last interacted course** only
- All tabs sync via `chrome.storage.onChanged` listener
- When Course B is clicked in Tab 2, Tab 1's badge updates automatically

---

## 🎓 Student Installation Guide

### Quick Install (2 Minutes!)

1. **Download** the extension ZIP file from your instructor
2. **Extract** the ZIP to any folder (e.g., Desktop)
3. **Open Chrome** and go to `chrome://extensions/`
4. **Enable Developer Mode** (toggle in top-right corner)
5. **Click "Load unpacked"** and select the extracted folder
6. **Done!** Go to [Google Classroom](https://classroom.google.com)
7. **Click "Allow"** when Google asks for permission
8. **Start downloading!** Click the floating button on any course

### First-Time Login

- Click "Sign in with Google" when prompted
- Use your **university Google account**
- Allow the requested permissions
- You'll see YOUR courses (not your instructor's!)

### Student Troubleshooting

| Problem | Solution |
|---------|----------|
| "OAuth error" | Make sure you're signed into your university Google account |
| Button not visible | Refresh the page (Ctrl+R) |
| "Extension ID error" | Re-download and reinstall the extension |
| Can't see courses | You must be enrolled in at least one Google Classroom course |
| Downloads failing | Check your internet connection and try again |

---

## 🛠️ For Developers

## 🚀 Installation

### Developer Setup

1. **Clone/Download this repository**
   ```bash
   git clone https://github.com/your-username/gcr-downloader.git
   cd gcr-downloader
   ```

2. **Create Google Cloud Project**
   - Go to [Google Cloud Console](https://console.cloud.google.com)
   - Create a new project named "GCR Downloader"
   - Navigate to "APIs & Services" → "Library"
   - Enable **Google Classroom API**
   - Enable **Google Drive API**

3. **Create OAuth Credentials**
   - Go to "APIs & Services" → "Credentials"
   - Click "Create Credentials" → "OAuth Client ID"
   - Select **Chrome Extension** as application type
   - Enter your Extension ID (get this from Step 5)
   - Copy the **Client ID**

4. **Configure the Extension**
   - Open `manifest.json`
   - Replace `YOUR_CLIENT_ID.apps.googleusercontent.com` with your Client ID:
   ```json
   "oauth2": {
     "client_id": "123456789-abc123.apps.googleusercontent.com",
     ...
   }
   ```

5. **Load in Chrome**
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode" (top right toggle)
   - Click "Load unpacked"
   - Select the `gcr-downloader` folder
   - Copy the **Extension ID** shown (looks like: `abcdefghijklmnop...`)
   - ⚠️ **IMPORTANT**: You MUST update Google Cloud OAuth client with this Extension ID, or authentication will fail!

6. **Test the Extension**
   - Navigate to [Google Classroom](https://classroom.google.com)
   - You should see a floating "Download" button in the bottom-right
   - Click a course, and the button will start loading materials
   - Click the button to see and download materials!

### ⚠️ Common Setup Mistakes

| Issue | Cause | Fix |
|-------|-------|-----|
| "Invalid OAuth client" | Extension ID mismatch | Re-copy ID from chrome://extensions |
| "API not enabled" | Forgot to enable APIs | Enable both Classroom + Drive APIs |
| "Client ID not found" | Wrong format | Should end with `.apps.googleusercontent.com` |
| Button not visible | Wrong URL match | Must be on `classroom.google.com` |

---

## 📖 Usage Guide

### First Time Setup
1. Install the extension and navigate to Google Classroom
2. You'll see "Download" button with no badge (fresh install)
3. Click on any course
4. Click "Allow" when Google asks for permissions
5. Button shows loading, then updates with file count

### Downloading Files
1. **Automatic Detection**: Just visit a course - data fetches automatically
2. **Click Button**: Opens selection popup
3. **Select Files**: Check/uncheck files to download
4. **Download**: Click "Download Selected"
5. **Progress**: Watch the progress bar

### Download Location

Files are saved to your Chrome downloads folder:
- **Windows**: `C:\Users\YourName\Downloads\[CourseName]\`
- **Mac**: `/Users/YourName/Downloads/[CourseName]/`
- **Linux**: `/home/yourname/Downloads/[CourseName]/`

⚠️ **Note**: If Chrome setting "Ask where to save each file" is enabled, you'll be prompted for each file (not recommended for batch downloads).

### Button Behavior

| Location | Button Shows | Behavior |
|----------|-------------|----------|
| Dashboard (first time) | "Download" (no badge) | Empty state |
| Course Page | "[24]" (loading then count) | Fetches materials |
| Dashboard (after course) | "[24]" (retained) | Shows last course |
| Different Course | Loading → "[18]" | Clears old, fetches new |
| Offline | Grayed button | Downloads disabled |

---

## 🏗️ Project Structure

```
gcr-downloader/
├── manifest.json        # Extension configuration
├── background.js        # Service worker (API, auth, downloads)
├── content.js           # Floating button & course detection
├── popup.html           # Extension popup UI
├── popup.js             # Popup logic
├── styles.css           # Button & modal styles
├── utils/
│   ├── auth.js          # OAuth 2.0 handling
│   ├── api.js           # Classroom/Drive API calls
│   ├── cache.js         # Course data caching
│   ├── download.js      # Download manager
│   ├── courseDetector.js # URL monitoring
│   └── helpers.js       # Utility functions
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md
```

---

## 🔧 Technical Details

### Course Detection Strategy

The extension uses multiple methods to detect course changes:

1. **History API Interception**: Catches `pushState` and `replaceState` calls
2. **MutationObserver**: Watches for DOM changes indicating navigation
3. **popstate Event**: Handles browser back/forward buttons
4. **Polling Fallback**: Checks URL every second as backup

All detection is **debounced by 500ms** to prevent rapid-fire fetches during fast navigation.

**Rapid Navigation Behavior:**
1. User clicks Course A (0ms) → Starts 500ms debounce timer
2. User clicks Course B (200ms) → `clearTimeout(timerA)`, cancel in-flight fetch, start 500ms timer for B
3. Only Course B gets fetched after timer completes

### Caching Strategy

```javascript
// Storage Keys
{
  "gcr_last_course_id": "ABC123",           // Current course ID
  "gcr_last_course_name": "CS101",          // Course name
  "gcr_course_data_ABC123": {               // Course materials
    "assignments": [...],
    "materials": [...],
    "announcements": [...],
    "links": [...],
    "totalItems": 24,
    "timestamp": 1703145600000
  }
}
```

- Only **one course** is cached at a time
- Old course data is **cleared** when visiting a new course
- Cache persists across page refreshes and browser restarts
- Maximum cache size: 5MB
- **Quota exceeded handling**: Auto-clears old data and retries

### Download Management

- **Concurrent Limit**: 5 files downloading simultaneously
- **Queue Size**: Unlimited (downloads in batches of 5)
- **Practical Limit**: ~200 files recommended per session
- **Retry Logic**: Automatically retries failed downloads (3 attempts)
- **Filename Sanitization**: Removes emojis, special characters, truncates to 100 chars
- **Unique Names**: Appends (1), (2), etc. for duplicates
- **Deduplication**: Same file in multiple categories downloaded only once (by Drive ID)
- **Organized**: Files saved to folder named after course

Example: Select 100 files → Downloads in batches of 5 → All 100 complete

### Duplicate File Handling

Files are uniquely identified by **Google Drive file ID**:
- Same file appearing in Assignments AND Materials → Downloaded once
- UI shows file in both places, but download is deduplicated
- Saves time and bandwidth

### API Rate Limits

Google imposes these limits:
- **Classroom API**: 10,000 requests/day (per project)
- **Drive API**: 1,000 requests/100 seconds/user

**What this means:**
- ~100 students can use your extension simultaneously
- Each course fetch = ~3-5 API calls
- Hitting limits? Request quota increase from Google (usually approved)

**Rate limit handling:**
- Automatic exponential backoff
- User-friendly error messages
- Retry after delay

### Sign Out Behavior

When user signs out:
1. ✅ OAuth token revoked
2. ✅ Auth state cleared
3. ✅ Cached data **retained** (for viewing)
4. ✅ Button shows "Sign in to download"
5. ✅ Next click triggers re-auth
6. ✅ Downloads require re-authentication

### Offline Behavior

When network is unavailable:
- ✅ Cached data **still visible** (read-only)
- ✅ Downloads disabled with "No internet" message
- ✅ Button shows gray offline indicator
- ✅ Automatically retries when online detected

---

## 🐛 Troubleshooting

### Quick Fixes (Try These First!)

1. ⟳ **Refresh the page** (Ctrl+R / Cmd+R)
2. 🔄 **Click "Sign Out" in popup → Sign in again**
3. 🗑️ **Clear extension cache** (Click 🗑️ in popup header)
4. 🔁 **Reload extension** (chrome://extensions → Toggle off/on)

### Detailed Solutions

### "OAuth error" or "Authentication failed"
1. Check that Client ID in manifest.json is correct
2. Verify Extension ID in Google Cloud Console matches
3. Ensure Classroom and Drive APIs are enabled

### "I clicked Deny by accident"
1. Right-click extension icon → Remove from Chrome
2. Re-add extension
3. OR: chrome://settings/content/all → Find classroom.google.com → Remove permissions
4. Refresh Classroom page → OAuth will re-trigger

### Button not appearing
1. Refresh the page
2. Check if you're on classroom.google.com
3. Open DevTools (F12) and check for errors

### "Button shows wrong course data"
1. Go to chrome://extensions
2. Find GCR Downloader → Details → Extension options
3. Click "Clear All Cache"
4. Refresh Classroom page

### Downloads failing
1. Check internet connection
2. Try signing out and back in
3. Check if file has restricted permissions
4. Look at console for specific error messages

### "Download stuck at 0%"
1. Check if Chrome is blocking downloads
2. Go to chrome://settings/downloads
3. Ensure "Ask where to save files" is OFF (or handle manually)

### "Too many files to download"
- Extension queues all files, downloads 5 at a time
- For 100+ files, wait for completion
- Download in batches for very large courses

### Token expired during download
- Extension will pause and prompt for re-authentication
- Downloads resume after signing in again

---

## ⚠️ Known Limitations

- **File Size**: Chrome may fail downloads >2GB
- **Concurrent Limit**: 5 files at a time (queues the rest)
- **Rate Limiting**: Google limits to ~100 requests/minute
- **Private Files**: Cannot download files you don't have permission for
- **Offline Mode**: Requires internet for downloads (cache viewable offline)
- **Mobile**: Not supported (Chrome extensions are desktop-only)

**Workaround for large courses:** Downloads queue automatically, just wait!

---

## 🔐 Privacy & Security

- **No Data Collection**: All processing happens locally
- **No External Servers**: No data sent anywhere except Google APIs
- **Minimal Permissions**: Only requests necessary scopes
- **Secure Storage**: Tokens stored in Chrome's secure storage
- **No Credentials Stored**: Only OAuth tokens, never passwords

---

## 📝 Permissions Explained

| Permission | Why Needed |
|------------|-----------|
| `identity` | OAuth authentication with Google |
| `storage` | Cache course data locally |
| `downloads` | Save files to your computer |
| `webNavigation` | Detect page navigation |
| `classroom.google.com` | Access Classroom pages |
| `googleapis.com` | Call Google APIs |

---

## 📜 Changelog

### Version 1.0.0 (2024-12-20)
- 🎉 Initial release
- ✅ Smart course detection with debouncing
- ✅ Intelligent caching with auto-invalidation
- ✅ Batch downloads with progress tracking
- ✅ 15+ file types supported
- ✅ OAuth 2.0 authentication
- ✅ Multi-tab synchronization
- ✅ Offline mode detection
- ✅ Duplicate file deduplication

### Planned Features (v1.1.0)
- [ ] Export as ZIP
- [ ] Dark mode
- [ ] Download history
- [ ] Keyboard shortcuts
- [ ] Settings panel

---

## 💬 Support & Feedback

- 🐛 **Bug Reports**: [Open an issue](https://github.com/your-username/gcr-downloader/issues)
- 💡 **Feature Requests**: [Start a discussion](https://github.com/your-username/gcr-downloader/discussions)
- ❓ **Questions**: Check the FAQ above first

**Before reporting bugs, please:**
1. Check existing issues
2. Include Chrome version
3. Include error messages from console (F12 → Console)
4. Describe steps to reproduce

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

---

## 📃 License

MIT License - feel free to use and modify!

---

## 🙏 Acknowledgments

- Google Classroom API documentation
- Google Drive API documentation
- Chrome Extension Manifest V3 documentation

---

Made with ❤️ for students everywhere
